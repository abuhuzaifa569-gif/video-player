package com.mylock.videoplayer

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.os.Bundle
import android.util.Log
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import java.io.File
import java.io.FileOutputStream
import kotlin.concurrent.thread

/**
 * Built-in automatic self-test for Video Player. Verifies the library query,
 * formatting helpers, resume/favorites storage (with cleanup), subtitle MIME
 * guessing, Media3 ExoPlayer wiring, a real framework playback pass on a
 * generated test tone, PiP capability and — critically — that the app holds
 * NO INTERNET permission. Results are shown on screen and logged (tag VPTEST)
 * for CI.
 */
class SelfTestActivity : Activity() {

    companion object { const val TAG = "VPTEST" }

    private lateinit var box: LinearLayout
    private lateinit var summaryTxt: android.widget.TextView
    private var running = false

    data class Result(val name: String, val status: String, val detail: String)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Ui.BG)
        root.setPadding(Ui.dp(this, 14), Ui.dp(this, 16), Ui.dp(this, 14), Ui.dp(this, 14))
        root.addView(Ui.text(this, "🧪 Video Player Auto Test", 17f, Ui.TEXT, true))
        summaryTxt = Ui.text(this, "Testing…", 14f, Ui.GOLD, true)
        root.addView(summaryTxt)
        val scroll = ScrollView(this)
        scroll.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        scroll.addView(box)
        root.addView(scroll)
        setContentView(root)
        Ui.edgeToEdge(this, root)
        runTests()
    }

    private fun addRow(r: Result) {
        val icon = when (r.status) { "PASS" -> "✅"; "FAIL" -> "❌"; else -> "⏭️" }
        val color = when (r.status) { "PASS" -> Ui.SECONDARY; "FAIL" -> Ui.ERROR; else -> Ui.GOLD }
        val t = Ui.text(this, "$icon ${r.name}" + if (r.detail.isNotEmpty()) "\n${r.detail}" else "", 13f, color)
        t.setPadding(0, Ui.dp(this, 5), 0, Ui.dp(this, 5))
        box.addView(t)
        Log.i(TAG, "CHECK ${r.name}: ${r.status} ${r.detail}")
    }

    class SkipException(msg: String) : Exception(msg)

    private fun check(name: String, block: () -> String): Result {
        return try {
            Result(name, "PASS", block())
        } catch (e: SkipException) {
            Result(name, "SKIP", e.message ?: "")
        } catch (e: Exception) {
            Result(name, "FAIL", e.javaClass.simpleName + ": " + (e.message ?: ""))
        }
    }

    /** Writes a valid 1-second silent WAV (44.1 kHz, 16-bit mono) and returns the file. */
    private fun makeToneWav(): File {
        val rate = 44100
        val samples = rate
        val f = File(cacheDir, "vp_selftest_tone.wav")
        FileOutputStream(f).use { out ->
            val dataSize = samples * 2
            fun wInt(v: Int) { out.write(v and 0xff); out.write((v shr 8) and 0xff); out.write((v shr 16) and 0xff); out.write((v shr 24) and 0xff) }
            fun wShort(v: Int) { out.write(v and 0xff); out.write((v shr 8) and 0xff) }
            out.write("RIFF".toByteArray()); wInt(36 + dataSize)
            out.write("WAVE".toByteArray()); out.write("fmt ".toByteArray())
            wInt(16); wShort(1); wShort(1); wInt(rate); wInt(rate * 2); wShort(2); wShort(16)
            out.write("data".toByteArray()); wInt(dataSize)
            out.write(ByteArray(dataSize))
        }
        return f
    }

    private fun runTests() {
        if (running) return
        running = true
        box.removeAllViews()
        Log.i(TAG, "START Video Player self-test")
        thread {
            val results = mutableListOf<Result>()
            val fakeId = 999999002L

            results.add(check("NO INTERNET permission (offline guarantee)") {
                val info = packageManager.getPackageInfo(packageName, PackageManager.GET_PERMISSIONS)
                val perms = info.requestedPermissions?.toList() ?: emptyList()
                if (perms.any { it == "android.permission.INTERNET" })
                    throw IllegalStateException("INTERNET permission present!")
                "permissions held: ${perms.size} — INTERNET absent"
            })
            results.add(check("Library query (MediaStore videos)") {
                val vids = Library.loadVideos(this)
                "query OK — ${vids.size} videos visible (0 is fine on a fresh emulator)"
            })
            results.add(check("Time + size formatting") {
                if (Library.fmtTime(0) != "0:00") throw IllegalStateException("fmtTime(0)=${Library.fmtTime(0)}")
                if (Library.fmtTime(61000) != "1:01") throw IllegalStateException("fmtTime(61s)=${Library.fmtTime(61000)}")
                if (Library.fmtTime(3661000) != "1:01:01") throw IllegalStateException("fmtTime(1h)=${Library.fmtTime(3661000)}")
                if (Library.fmtSize(1024 * 1024) != "1.0 MB") throw IllegalStateException("fmtSize(1MB)=${Library.fmtSize(1024 * 1024)}")
                if (Library.fmtSize(2L * 1024 * 1024 * 1024) != "2.00 GB") throw IllegalStateException("fmtSize(2GB)=${Library.fmtSize(2L * 1024 * 1024 * 1024)}")
                "0:00 / 1:01 / 1:01:01 / 1.0 MB / 2.00 GB all correct"
            })
            results.add(check("Sorting (all 4 modes)") {
                val fake = listOf(
                    Video(1, "b.mp4", "F", "1", 5000, 300, 1920, 1080, 100, ""),
                    Video(2, "a.mp4", "F", "1", 9000, 100, 1280, 720, 300, ""),
                    Video(3, "c.mp4", "F", "1", 1000, 900, 640, 480, 200, "")
                )
                if (Library.sortVideos(fake, 0).first().id != 2L) throw IllegalStateException("name sort wrong")
                if (Library.sortVideos(fake, 1).first().id != 2L) throw IllegalStateException("date sort wrong")
                if (Library.sortVideos(fake, 2).first().id != 2L) throw IllegalStateException("duration sort wrong")
                if (Library.sortVideos(fake, 3).first().id != 3L) throw IllegalStateException("size sort wrong")
                "name/date/duration/size orders all correct"
            })
            results.add(check("Subtitle MIME guessing") {
                if (Library.subtitleMime("movie.srt") != MimeTypes.APPLICATION_SUBRIP) throw IllegalStateException("srt")
                if (Library.subtitleMime("movie.vtt") != MimeTypes.TEXT_VTT) throw IllegalStateException("vtt")
                if (Library.subtitleMime("movie.ass") != MimeTypes.TEXT_SSA) throw IllegalStateException("ass")
                if (Library.subtitleMime("movie.ttml") != MimeTypes.APPLICATION_TTML) throw IllegalStateException("ttml")
                "srt/vtt/ass/ttml MIME mapping correct"
            })
            results.add(check("Resume save + read + clear (cleaned up)") {
                Prefs.clearResume(fakeId)
                Prefs.saveResume(fakeId, 60_000, 600_000)
                val back = Prefs.resumePos(fakeId)
                if (back != 60_000L) throw IllegalStateException("resume read back $back")
                Prefs.saveResume(fakeId, 595_000, 600_000) // near end → auto-clears
                if (Prefs.resumePos(fakeId) != 0L) throw IllegalStateException("near-end resume not cleared")
                Prefs.clearResume(fakeId)
                "save/read/auto-clear verified, nothing left behind"
            })
            results.add(check("Favorites toggle (state restored)") {
                val wasFav = Prefs.isFavorite(fakeId)
                val now = Prefs.toggleFavorite(fakeId)
                if (now == wasFav) throw IllegalStateException("toggle did not change state")
                Prefs.toggleFavorite(fakeId)
                if (Prefs.isFavorite(fakeId) != wasFav) throw IllegalStateException("state not restored")
                "toggle on/off verified, original state restored"
            })
            results.add(check("Recents readable") {
                val r = Prefs.recents()
                "recents=${r.size} entries"
            })
            results.add(check("Media3 ExoPlayer wiring") {
                val cls = Class.forName("androidx.media3.exoplayer.ExoPlayer")
                val item = MediaItem.Builder().setUri("file:///tmp/none.mp4").build()
                if (item.localConfiguration?.uri == null) throw IllegalStateException("MediaItem uri lost")
                val intent = Intent(this, PlayerActivity::class.java)
                "ExoPlayer class loaded (${cls.simpleName}), MediaItem builds, PlayerActivity intent OK"
            })
            results.add(check("Framework playback sanity (test tone)") {
                val wav = makeToneWav()
                val mp = MediaPlayer()
                try {
                    mp.setDataSource(wav.absolutePath)
                    mp.prepare()
                    val dur = mp.duration
                    if (dur < 900 || dur > 1100) throw IllegalStateException("duration=${dur}ms, expected ~1000")
                    mp.start(); Thread.sleep(200)
                    if (!mp.isPlaying) throw IllegalStateException("not playing after start()")
                    mp.pause()
                    "prepare/start/pause OK, duration ${dur}ms (device media stack alive)"
                } finally {
                    try { mp.release() } catch (e: Exception) { }
                    wav.delete()
                }
            })
            results.add(check("Picture-in-Picture capability") {
                val has = packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)
                "PiP system feature present: $has (player enters PiP only when supported)"
            })
            results.add(check("Target SDK is 35 (Android 15)") {
                @Suppress("DEPRECATION")
                val ti = applicationInfo.targetSdkVersion
                if (ti != 35) throw IllegalStateException("targetSdk=$ti")
                "targetSdkVersion = 35"
            })
            results.add(check("v2.0 Theme pref roundtrip (restored)") {
                val was = Prefs.themeDark
                Prefs.themeDark = !was
                if (Prefs.themeDark == was) throw IllegalStateException("theme pref did not flip")
                Prefs.themeDark = was
                if (Prefs.themeDark != was) throw IllegalStateException("theme pref not restored")
                "dark=${was} flip + restore OK"
            })
            results.add(check("v2.0 Double-tap skip + repeat/shuffle prefs (restored)") {
                val s0 = Prefs.tapSeekSeconds; val r0 = Prefs.repeatMode; val sh0 = Prefs.shuffle
                Prefs.tapSeekSeconds = 20; Prefs.repeatMode = 1; Prefs.shuffle = !sh0
                if (Prefs.tapSeekSeconds != 20) throw IllegalStateException("tap seek not saved")
                if (Prefs.repeatMode != 1) throw IllegalStateException("repeat mode not saved")
                if (Prefs.shuffle == sh0) throw IllegalStateException("shuffle not saved")
                Prefs.tapSeekSeconds = s0; Prefs.repeatMode = r0; Prefs.shuffle = sh0
                "seek/repeat/shuffle save + restore OK"
            })
            results.add(check("v2.0 Playlist create/add/remove/delete (cleaned up)") {
                val name = "__selftest_playlist__"
                Prefs.deletePlaylist(name)
                if (!Prefs.createPlaylist(name)) throw IllegalStateException("create failed")
                if (Prefs.createPlaylist(name)) throw IllegalStateException("duplicate create allowed")
                if (!Prefs.addToPlaylist(name, fakeId)) throw IllegalStateException("add failed")
                if (Prefs.addToPlaylist(name, fakeId)) throw IllegalStateException("duplicate add allowed")
                val got = Prefs.playlists().firstOrNull { it.first == name }
                if (got == null || got.second != listOf(fakeId)) throw IllegalStateException("contents wrong: $got")
                Prefs.removeFromPlaylist(name, fakeId)
                if (Prefs.playlists().first { it.first == name }.second.isNotEmpty()) throw IllegalStateException("remove failed")
                Prefs.deletePlaylist(name)
                if (Prefs.playlists().any { it.first == name }) throw IllegalStateException("delete failed")
                "playlist lifecycle OK, nothing left behind"
            })
            results.add(check("v2.0 Private PIN set/verify (cleaned up)") {
                if (Prefs.hasPin()) throw SkipException("a real user PIN exists — not touched")
                Prefs.setPin("7391")
                if (!Prefs.hasPin()) throw IllegalStateException("pin not stored")
                if (!Prefs.verifyPin("7391")) throw IllegalStateException("correct PIN rejected")
                if (Prefs.verifyPin("0000")) throw IllegalStateException("wrong PIN accepted!")
                Prefs.clearPin()
                if (Prefs.hasPin()) throw IllegalStateException("pin not cleared")
                "PBKDF2 PIN set/verify/reject/clear OK"
            })
            results.add(check("v2.0 Hidden (private) ids roundtrip (restored)") {
                val wasHidden = Prefs.hiddenIds().contains(fakeId)
                Prefs.setHidden(fakeId, true)
                if (!Prefs.hiddenIds().contains(fakeId)) throw IllegalStateException("hide failed")
                Prefs.setHidden(fakeId, false)
                if (Prefs.hiddenIds().contains(fakeId)) throw IllegalStateException("unhide failed")
                if (wasHidden) Prefs.setHidden(fakeId, true)
                "hide/unhide OK"
            })
            results.add(check("v2.0 Equalizer prefs roundtrip (restored)") {
                val l0 = Prefs.eqLevels(); val p0 = Prefs.eqPreset; val b0 = Prefs.eqBass; val e0 = Prefs.eqEnabled
                Prefs.saveEqLevels(listOf(-300, 0, 300, 150, -150))
                Prefs.eqPreset = -1; Prefs.eqBass = 400; Prefs.eqEnabled = true
                if (Prefs.eqLevels() != listOf(-300, 0, 300, 150, -150)) throw IllegalStateException("levels wrong: ${Prefs.eqLevels()}")
                if (Prefs.eqBass != 400) throw IllegalStateException("bass not saved")
                if (!Prefs.eqEnabled) throw IllegalStateException("enabled not saved")
                if (l0.isEmpty()) Prefs.clearEq() else Prefs.saveEqLevels(l0)
                Prefs.eqPreset = p0; Prefs.eqBass = b0; Prefs.eqEnabled = e0
                "levels/bass/enabled save + restore OK"
            })

            results.add(check("v2.3 Player screen constructs (crash regression)") {
                // The v2.0-v2.2 crash: PlayerActivity's constructor built a
                // ScaleGestureDetector before the context was attached (NPE).
                // Instantiating the class runs that constructor; it must not throw.
                val ctor = PlayerActivity::class.java.getDeclaredConstructor()
                ctor.isAccessible = true
                ctor.newInstance()
                "PlayerActivity constructor OK (no early-context use)"
            })

            val pass = results.count { it.status == "PASS" }
            val fail = results.count { it.status == "FAIL" }
            val skip = results.count { it.status == "SKIP" }
            runOnUiThread {
                for (r in results) addRow(r)
                summaryTxt.text = if (fail == 0) "✅ ALL OK — $pass passed, $skip skipped" else "❌ $fail FAILED — $pass passed, $skip skipped"
                Log.i(TAG, "SUMMARY: $pass PASS, $fail FAIL, $skip SKIP (of ${results.size})")
                running = false
                Toast.makeText(this, "Auto test: $pass/${results.size} passed", Toast.LENGTH_LONG).show()
            }
        }
    }
}
