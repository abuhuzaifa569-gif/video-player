package com.mylock.videoplayer

import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Size
import androidx.media3.common.MimeTypes
import java.util.Locale

data class Video(
    val id: Long,
    val title: String,
    val folder: String,
    val bucketId: String,
    val duration: Long,
    val sizeBytes: Long,
    val width: Int,
    val height: Int,
    val dateAdded: Long,
    val path: String
) {
    val uri: Uri get() = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id)
    val resolution: String get() = if (width > 0 && height > 0) "${width}×${height}" else "Unknown res"
}

object Library {

    fun fmtTime(ms: Long): String {
        if (ms <= 0) return "0:00"
        val s = (ms / 1000).toInt()
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec)
        else String.format(Locale.US, "%d:%02d", m, sec)
    }

    fun fmtSize(bytes: Long): String {
        if (bytes <= 0) return "—"
        val kb = bytes / 1024.0
        val mb = kb / 1024.0
        val gb = mb / 1024.0
        return when {
            gb >= 1.0 -> String.format(Locale.US, "%.2f GB", gb)
            mb >= 1.0 -> String.format(Locale.US, "%.1f MB", mb)
            else -> String.format(Locale.US, "%.0f KB", kb)
        }
    }

    fun sortVideos(list: List<Video>, mode: Int): List<Video> = when (mode) {
        0 -> list.sortedBy { it.title.lowercase(Locale.US) }
        2 -> list.sortedByDescending { it.duration }
        3 -> list.sortedByDescending { it.sizeBytes }
        else -> list.sortedByDescending { it.dateAdded } // 1 = date newest (default)
    }

    /** MIME type for an external subtitle file, guessed from its extension. */
    fun subtitleMime(fileName: String): String {
        val lower = fileName.lowercase(Locale.US)
        return when {
            lower.endsWith(".vtt") -> MimeTypes.TEXT_VTT
            lower.endsWith(".ssa") || lower.endsWith(".ass") -> MimeTypes.TEXT_SSA
            lower.endsWith(".ttml") || lower.endsWith(".xml") || lower.endsWith(".dfxp") -> MimeTypes.APPLICATION_TTML
            else -> MimeTypes.APPLICATION_SUBRIP // .srt and anything else
        }
    }

    fun loadVideos(ctx: Context): List<Video> {
        val out = mutableListOf<Video>()
        val proj = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.BUCKET_DISPLAY_NAME,
            MediaStore.Video.Media.BUCKET_ID,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.WIDTH,
            MediaStore.Video.Media.HEIGHT,
            MediaStore.Video.Media.DATE_ADDED,
            MediaStore.Video.Media.DATA
        )
        try {
            ctx.contentResolver.query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI, proj, null, null,
                "${MediaStore.Video.Media.DATE_ADDED} DESC"
            )?.use { c ->
                val iId = c.getColumnIndex(MediaStore.Video.Media._ID)
                val iName = c.getColumnIndex(MediaStore.Video.Media.DISPLAY_NAME)
                val iFolder = c.getColumnIndex(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)
                val iBucket = c.getColumnIndex(MediaStore.Video.Media.BUCKET_ID)
                val iDur = c.getColumnIndex(MediaStore.Video.Media.DURATION)
                val iSize = c.getColumnIndex(MediaStore.Video.Media.SIZE)
                val iW = c.getColumnIndex(MediaStore.Video.Media.WIDTH)
                val iH = c.getColumnIndex(MediaStore.Video.Media.HEIGHT)
                val iDate = c.getColumnIndex(MediaStore.Video.Media.DATE_ADDED)
                val iData = c.getColumnIndex(MediaStore.Video.Media.DATA)
                while (c.moveToNext()) {
                    out.add(
                        Video(
                            c.getLong(iId),
                            if (iName >= 0) c.getString(iName) ?: "Video" else "Video",
                            if (iFolder >= 0) c.getString(iFolder) ?: "Unknown folder" else "Unknown folder",
                            if (iBucket >= 0) c.getString(iBucket) ?: "" else "",
                            if (iDur >= 0) c.getLong(iDur) else 0,
                            if (iSize >= 0) c.getLong(iSize) else 0,
                            if (iW >= 0) c.getInt(iW) else 0,
                            if (iH >= 0) c.getInt(iH) else 0,
                            if (iDate >= 0) c.getLong(iDate) else 0,
                            if (iData >= 0) c.getString(iData) ?: "" else ""
                        )
                    )
                }
            }
        } catch (e: Exception) { /* permission not granted yet */ }
        return out
    }

    /** Video thumbnail via the platform thumbnail loader (API 29+); null below that. */
    fun thumbnail(ctx: Context, v: Video): Bitmap? {
        if (Build.VERSION.SDK_INT < 29) return null
        return try {
            ctx.contentResolver.loadThumbnail(v.uri, Size(320, 180), null)
        } catch (e: Exception) { null }
    }
}
