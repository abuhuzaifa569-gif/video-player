package com.mylock.videoplayer

import android.graphics.Bitmap

/**
 * Bridge between PlayerActivity (which owns the ExoPlayer) and PlayerService
 * (which owns the notification / player bar). The activity registers its
 * callbacks while alive; the service only forwards button presses.
 */
object PlayerBridge {
    var title: String = "Video Player"
    var isPlaying: () -> Boolean = { false }
    var onToggle: (() -> Unit)? = null
    var onNext: (() -> Unit)? = null
    var onPrev: (() -> Unit)? = null
    var onClose: (() -> Unit)? = null
    @Volatile var thumb: Bitmap? = null
    var active: Boolean = false

    fun clear() {
        onToggle = null
        onNext = null
        onPrev = null
        onClose = null
        thumb = null
        active = false
    }
}
