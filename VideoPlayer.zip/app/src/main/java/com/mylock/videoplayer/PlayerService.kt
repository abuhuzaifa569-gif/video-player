package com.mylock.videoplayer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.BitmapFactory
import android.graphics.drawable.Icon
import android.os.Build
import android.os.IBinder

/**
 * Background-play foreground service: keeps a player bar (notification) on the
 * home / notification screen and the LOCK screen with thumbnail + title and
 * Previous / Play-Pause / Next / Close controls. The ExoPlayer itself stays in
 * PlayerActivity; this service only draws the bar and forwards presses through
 * PlayerBridge. Tapping the bar re-opens the player.
 */
class PlayerService : Service() {

    companion object {
        const val ACTION_TOGGLE = "vp.TOGGLE"
        const val ACTION_NEXT = "vp.NEXT"
        const val ACTION_PREV = "vp.PREV"
        const val ACTION_CLOSE = "vp.CLOSE"
        const val ACTION_REFRESH = "vp.REFRESH"
        var running = false
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel("playback") == null) {
            val ch = NotificationChannel("playback", "Playback", NotificationManager.IMPORTANCE_LOW)
            ch.description = "Background playback controls"
            ch.setShowBadge(false)
            nm.createNotificationChannel(ch)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_TOGGLE -> PlayerBridge.onToggle?.invoke()
            ACTION_NEXT -> PlayerBridge.onNext?.invoke()
            ACTION_PREV -> PlayerBridge.onPrev?.invoke()
            ACTION_CLOSE -> {
                PlayerBridge.onClose?.invoke()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
        }
        showBar()
        return START_STICKY
    }

    private fun pending(action: String, code: Int): PendingIntent {
        val intent = Intent(this, PlayerService::class.java).setAction(action)
        return PendingIntent.getService(
            this, code, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun showBar() {
        val playing = try { PlayerBridge.isPlaying() } catch (e: Exception) { false }
        val openIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, PlayerActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val playIcon = if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
        val b = Notification.Builder(this, "playback")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(PlayerBridge.title)
            .setContentText(if (playing) "Playing in background" else "Paused")
            .setContentIntent(openIntent)
            .setVisibility(Notification.VISIBILITY_PUBLIC) // full controls on the lock screen
            .setOngoing(playing)
            .addAction(Notification.Action.Builder(
                Icon.createWithResource(this, android.R.drawable.ic_media_previous), "Previous", pending(ACTION_PREV, 1)).build())
            .addAction(Notification.Action.Builder(
                Icon.createWithResource(this, playIcon), if (playing) "Pause" else "Play", pending(ACTION_TOGGLE, 2)).build())
            .addAction(Notification.Action.Builder(
                Icon.createWithResource(this, android.R.drawable.ic_media_next), "Next", pending(ACTION_NEXT, 3)).build())
            .addAction(Notification.Action.Builder(
                Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Close", pending(ACTION_CLOSE, 4)).build())
            .setStyle(Notification.MediaStyle().setShowActionsInCompactView(0, 1, 2))
        val thumb = PlayerBridge.thumb
        if (thumb != null) {
            b.setLargeIcon(thumb)
        } else {
            try {
                val icon = BitmapFactory.decodeResource(resources, R.mipmap.ic_launcher)
                if (icon != null) b.setLargeIcon(icon)
            } catch (e: Exception) { }
        }
        val notif = b.build()
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
            } else {
                startForeground(1, notif)
            }
        } catch (e: Exception) {
            try { startForeground(1, notif) } catch (e2: Exception) { }
        }
    }

    override fun onDestroy() {
        running = false
        super.onDestroy()
    }
}
