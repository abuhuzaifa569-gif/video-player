package com.mylock.videoplayer

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * FINAL build (Moiz, 2026-11-11): the app's information pages — About, Help,
 * Privacy Policy, Licenses, What's New, Permissions — in the signature theme
 * and the final Quicksand font. Content approved from PAGES-DRAFT.md.
 * The "100% offline" slogan line was removed at Moiz's order; the privacy
 * facts themselves stay stated plainly inside the Privacy page.
 */
class InfoActivity : Activity() {

    private lateinit var titleTxt: TextView
    private lateinit var chipsRow: LinearLayout
    private lateinit var contentBox: LinearLayout
    private var page = 0

    private val pages = listOf("About", "Help", "Privacy", "Licenses", "What's New", "Permissions")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        Ui.applyTheme(Prefs.themeDark)
        page = intent.getIntExtra(EXTRA_PAGE, 0).coerceIn(0, pages.size - 1)
        buildUi()
        showPage(page)
    }

    private fun buildUi() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Ui.BG)

        val strip = View(this)
        strip.background = Ui.gradientStrip()
        strip.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 5))
        root.addView(strip)

        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        header.setPadding(Ui.dp(this, 8), Ui.dp(this, 10), Ui.dp(this, 14), Ui.dp(this, 6))
        val back = Ui.text(this, "‹", 26f, Ui.SECONDARY, true)
        back.setPadding(Ui.dp(this, 10), Ui.dp(this, 2), Ui.dp(this, 12), Ui.dp(this, 6))
        back.setOnClickListener { finish() }
        header.addView(back)
        titleTxt = Ui.text(this, pages[page], 19f, Ui.TEXT, true)
        header.addView(titleTxt)
        root.addView(header)

        val chipsScroll = HorizontalScrollView(this)
        chipsScroll.isHorizontalScrollBarEnabled = false
        chipsRow = LinearLayout(this)
        chipsRow.orientation = LinearLayout.HORIZONTAL
        chipsRow.setPadding(Ui.dp(this, 10), Ui.dp(this, 4), Ui.dp(this, 10), Ui.dp(this, 8))
        chipsScroll.addView(chipsRow)
        root.addView(chipsScroll)

        val scroll = ScrollView(this)
        scroll.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        contentBox = LinearLayout(this)
        contentBox.orientation = LinearLayout.VERTICAL
        contentBox.setPadding(Ui.dp(this, 16), Ui.dp(this, 6), Ui.dp(this, 16), Ui.dp(this, 22))
        scroll.addView(contentBox)
        root.addView(scroll)

        setContentView(root)
        Ui.edgeToEdge(this, root)
    }

    private fun renderChips() {
        chipsRow.removeAllViews()
        for (i in pages.indices) {
            val chip = TextView(this)
            Ui.style(chip, i == page)
            chip.text = pages[i]
            chip.textSize = 13f
            chip.setTextColor(if (i == page) Color.WHITE else Ui.TEXT)
            chip.background = if (i == page) Ui.gradientBtn(16) else Ui.cardBg(16, Ui.ELEVATED)
            chip.setPadding(Ui.dp(this, 12), Ui.dp(this, 7), Ui.dp(this, 12), Ui.dp(this, 7))
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.setMargins(Ui.dp(this, 4), 0, Ui.dp(this, 4), 0)
            chip.layoutParams = lp
            chip.setOnClickListener { showPage(i) }
            chipsRow.addView(chip)
        }
    }

    private fun showPage(i: Int) {
        page = i
        titleTxt.text = pages[i]
        renderChips()
        contentBox.removeAllViews()
        when (i) {
            0 -> aboutPage()
            1 -> helpPage()
            2 -> privacyPage()
            3 -> licensesPage()
            4 -> whatsNewPage()
            else -> permissionsPage()
        }
    }

    // ---------- content building helpers ----------

    private fun heading(s: String) {
        val t = Ui.text(this, s, 13.5f, Ui.SECONDARY, true)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = Ui.dp(this, 16)
        lp.bottomMargin = Ui.dp(this, 5)
        t.layoutParams = lp
        contentBox.addView(t)
    }

    private fun para(s: String, muted: Boolean = false) {
        val t = Ui.text(this, s, 14f, if (muted) Ui.MUTED else Ui.TEXT)
        t.setLineSpacing(0f, 1.35f)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.bottomMargin = Ui.dp(this, 7)
        t.layoutParams = lp
        contentBox.addView(t)
    }

    private fun bullet(s: String) = para("•  $s")

    // ---------- pages ----------

    private fun aboutPage() {
        val icon = ImageView(this)
        try { icon.setImageResource(R.mipmap.ic_launcher) } catch (e: Exception) { }
        val ilp = LinearLayout.LayoutParams(Ui.dp(this, 92), Ui.dp(this, 92))
        ilp.gravity = Gravity.CENTER_HORIZONTAL
        ilp.topMargin = Ui.dp(this, 10)
        ilp.bottomMargin = Ui.dp(this, 8)
        icon.layoutParams = ilp
        contentBox.addView(icon)

        val nameRow = LinearLayout(this)
        nameRow.orientation = LinearLayout.HORIZONTAL
        nameRow.gravity = Gravity.CENTER
        nameRow.addView(Ui.text(this, "Video ", 24f, Ui.TEXT, true))
        nameRow.addView(Ui.text(this, "Player", 24f, Ui.PRIMARY2, true))
        contentBox.addView(nameRow)

        val ver = Ui.text(this, "Version 3.1 · Final", 13f, Ui.MUTED)
        ver.gravity = Gravity.CENTER
        val vlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        vlp.topMargin = Ui.dp(this, 3)
        vlp.bottomMargin = Ui.dp(this, 6)
        ver.layoutParams = vlp
        contentBox.addView(ver)

        val tag = Ui.text(this, "A simple, fast and beautiful video player for all your videos.", 14f, Ui.TEXT)
        tag.gravity = Gravity.CENTER
        contentBox.addView(tag)

        heading("ABOUT THIS APP")
        para("Video Player plays all the videos on your phone with a clean signature design in Dark and Light themes. No ads, no accounts, no tracking — your videos never leave your device.")
        heading("KEY FEATURES")
        bullet("Dark (charcoal) and Light (cream) signature themes")
        bullet("5-band Equalizer with presets and Bass Boost")
        bullet("Background play — player bar on Home & Lock screen")
        bullet("Private folder protected by a PIN")
        bullet("Playlists, Favorites and Recent")
        bullet("Gestures: volume, brightness, double-tap skip, pinch zoom")
        bullet("Sleep timer, A–B repeat, screenshot, smart auto-rotate")
        val foot = Ui.text(this, "Support: (email to be added)\n© 2026 Video Player. All rights reserved.", 12f, Ui.MUTED)
        foot.gravity = Gravity.CENTER
        val flp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        flp.topMargin = Ui.dp(this, 16)
        foot.layoutParams = flp
        contentBox.addView(foot)
    }

    private fun helpPage() {
        heading("PLAYING")
        para("Tap any video to play. Tap the screen to show or hide the controls.")
        para("Left side swipe = brightness · Right side swipe = volume · Double-tap = skip · Pinch = zoom (1x–3x).")
        heading("EQUALIZER")
        para("In the player, open the menu → Equalizer. Pick a preset or move the 5 bands; Bass Boost is below the bands. Your settings are remembered.")
        heading("PRIVATE FOLDER")
        para("Set a PIN, open the Private tab and unlock it. Long-press any video → Move to Private to hide it from all lists.")
        heading("PLAYLISTS")
        para("Long-press a video → Add to playlist. Open the Playlists tab to play or manage them.")
        heading("BACKGROUND PLAY")
        para("Turn on Background Play in the player menu. Playback continues with the screen off, with a player bar on your Home and Lock screens. Tap the bar to return to the app.")
        heading("THEMES")
        para("Tap the sun/moon button at the top of the library to switch between Dark and Light.")
    }

    private fun privacyPage() {
        para("Last updated: November 2026", muted = true)
        heading("PRIVACY POLICY")
        para("Video Player is an offline app. It does NOT collect, share or sell any personal data.")
        para("No internet: the app has no INTERNET permission and cannot send data anywhere.")
        para("Your videos stay on your device — the app only reads them to show and play them.")
        para("Settings and your PIN are saved only on your device. The PIN is stored as a secure hash, never in plain text.")
        para("No ads · No analytics · No third-party trackers.")
        para("Questions: (email to be added)", muted = true)
    }

    private fun licensesPage() {
        heading("OPEN-SOURCE LICENSES")
        para("This app uses open-source software:")
        para("Media3 / ExoPlayer (Google) — Apache License 2.0")
        para("AndroidX libraries (Google) — Apache License 2.0")
        para("Kotlin (JetBrains) — Apache License 2.0")
        para("Full license texts are available at apache.org/licenses.", muted = true)
    }

    private fun whatsNewPage() {
        heading("VERSION 3.1 — FINAL")
        bullet("App information pages (About, Help, Privacy, Licenses)")
        bullet("Final Quicksand font across the app")
        bullet("New app icon (final design)")
        bullet("Signature design polish: wave header, cards, bottom bar")
        bullet("Crash fix verified on Android 10 and Android 15")
        heading("VERSION 2.0")
        bullet("Equalizer + Bass Boost, Dark/Light themes")
        bullet("Background play bar, Private folder (PIN), Playlists")
        bullet("Pinch zoom, sleep timer, A–B repeat, screenshot")
    }

    private fun permissionsPage() {
        heading("PERMISSIONS & WHY")
        para("Videos access — to list and play the videos on your phone. Nothing is uploaded.")
        para("Notifications — to show the background player bar (only when Background Play is on).")
        para("Foreground service — to keep playback running with the screen off.")
        para("Wake lock — to keep the screen on while a video plays.")
        para("The app has NO internet permission — it cannot send your data anywhere.", muted = true)
    }

    companion object {
        const val EXTRA_PAGE = "page"
    }
}
