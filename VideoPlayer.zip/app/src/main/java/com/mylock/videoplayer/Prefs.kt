package com.mylock.videoplayer

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private var spCache: SharedPreferences? = null
    fun init(ctx: Context) {
        spCache = ctx.applicationContext.getSharedPreferences("vp_prefs", Context.MODE_PRIVATE)
    }
    private fun sp() = spCache

    // 0 name A-Z, 1 date newest, 2 duration longest, 3 size largest
    var sortMode: Int
        get() = sp()?.getInt("sort", 1) ?: 1
        set(v) { sp()?.edit()?.putInt("sort", v)?.apply() }

    // ---- favorites: comma-separated video ids ----
    fun favorites(): MutableSet<Long> {
        val raw = sp()?.getString("favs", "") ?: ""
        return if (raw.isEmpty()) mutableSetOf()
        else raw.split(",").mapNotNull { it.toLongOrNull() }.toMutableSet()
    }

    fun toggleFavorite(id: Long): Boolean {
        val set = favorites()
        val added = if (set.contains(id)) { set.remove(id); false } else { set.add(id); true }
        sp()?.edit()?.putString("favs", set.joinToString(","))?.apply()
        return added
    }

    fun isFavorite(id: Long) = favorites().contains(id)

    // ---- recently played: most-recent-first ids ----
    fun recents(): List<Long> {
        val raw = sp()?.getString("recent", "") ?: ""
        return if (raw.isEmpty()) emptyList() else raw.split(",").mapNotNull { it.toLongOrNull() }
    }

    fun pushRecent(id: Long) {
        val list = recents().toMutableList()
        list.remove(id)
        list.add(0, id)
        sp()?.edit()?.putString("recent", list.take(50).joinToString(","))?.apply()
    }

    // ---- resume positions: per-video playback position (ms) ----
    fun resumePos(id: Long): Long = sp()?.getLong("pos_$id", 0L) ?: 0L

    fun saveResume(id: Long, posMs: Long, durationMs: Long) {
        // Near the start or near the end counts as "not started / finished".
        if (posMs < 5_000L || (durationMs > 0 && posMs > durationMs - 10_000L)) {
            clearResume(id)
            return
        }
        sp()?.edit()?.putLong("pos_$id", posMs)?.apply()
    }

    fun clearResume(id: Long) {
        sp()?.edit()?.remove("pos_$id")?.apply()
    }

    var lastSpeed: Float
        get() = sp()?.getFloat("speed", 1.0f) ?: 1.0f
        set(v) { sp()?.edit()?.putFloat("speed", v)?.apply() }
}
