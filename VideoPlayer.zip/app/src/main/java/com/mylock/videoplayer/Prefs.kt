package com.mylock.videoplayer

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private var spCache: SharedPreferences? = null
    fun init(ctx: Context) {
        spCache = ctx.applicationContext.getSharedPreferences("vp_prefs", Context.MODE_PRIVATE)
    }
    private fun sp() = spCache

    // 0 name A-Z, 1 date newest, 2 duration longest, 3 size largest
    var sortMode: Int
        get() = sp()?.getInt("sort", 1) ?: 1
        set(v) { sp()?.edit()?.putInt("sort", v)?.apply() }

    // ---- favorites: comma-separated video ids ----
    fun favorites(): MutableSet<Long> {
        val raw = sp()?.getString("favs", "") ?: ""
        return if (raw.isEmpty()) mutableSetOf()
        else raw.split(",").mapNotNull { it.toLongOrNull() }.toMutableSet()
    }

    fun toggleFavorite(id: Long): Boolean {
        val set = favorites()
        val added = if (set.contains(id)) { set.remove(id); false } else { set.add(id); true }
        sp()?.edit()?.putString("favs", set.joinToString(","))?.apply()
        return added
    }

    fun isFavorite(id: Long) = favorites().contains(id)

    // ---- recently played: most-recent-first ids ----
    fun recents(): List<Long> {
        val raw = sp()?.getString("recent", "") ?: ""
        return if (raw.isEmpty()) emptyList() else raw.split(",").mapNotNull { it.toLongOrNull() }
    }

    fun pushRecent(id: Long) {
        val list = recents().toMutableList()
        list.remove(id)
        list.add(0, id)
        sp()?.edit()?.putString("recent", list.take(50).joinToString(","))?.apply()
    }

    // ---- resume positions: per-video playback position (ms) ----
    fun resumePos(id: Long): Long = sp()?.getLong("pos_$id", 0L) ?: 0L

    fun saveResume(id: Long, posMs: Long, durationMs: Long) {
        // Near the start or near the end counts as "not started / finished".
        if (posMs < 5_000L || (durationMs > 0 && posMs > durationMs - 10_000L)) {
            clearResume(id)
            return
        }
        sp()?.edit()?.putLong("pos_$id", posMs)?.apply()
    }

    fun clearResume(id: Long) {
        sp()?.edit()?.remove("pos_$id")?.apply()
    }

    var lastSpeed: Float
        get() = sp()?.getFloat("speed", 1.0f) ?: 1.0f
        set(v) { sp()?.edit()?.putFloat("speed", v)?.apply() }

    // ---------------- v2.0 additions ----------------

    var themeDark: Boolean
        get() = sp()?.getBoolean("theme_dark", true) ?: true
        set(v) { sp()?.edit()?.putBoolean("theme_dark", v)?.apply() }

    var gridView: Boolean
        get() = sp()?.getBoolean("grid_view", false) ?: false
        set(v) { sp()?.edit()?.putBoolean("grid_view", v)?.apply() }

    var tapSeekSeconds: Int
        get() = sp()?.getInt("tap_seek", 10) ?: 10
        set(v) { sp()?.edit()?.putInt("tap_seek", v)?.apply() }

    // 0 = off, 1 = repeat all, 2 = repeat one
    var repeatMode: Int
        get() = sp()?.getInt("repeat_mode", 0) ?: 0
        set(v) { sp()?.edit()?.putInt("repeat_mode", v)?.apply() }

    var shuffle: Boolean
        get() = sp()?.getBoolean("shuffle", false) ?: false
        set(v) { sp()?.edit()?.putBoolean("shuffle", v)?.apply() }

    var bgPlay: Boolean
        get() = sp()?.getBoolean("bg_play", false) ?: false
        set(v) { sp()?.edit()?.putBoolean("bg_play", v)?.apply() }

    // ---- equalizer ----
    var eqEnabled: Boolean
        get() = sp()?.getBoolean("eq_on", false) ?: false
        set(v) { sp()?.edit()?.putBoolean("eq_on", v)?.apply() }

    var eqPreset: Int
        get() = sp()?.getInt("eq_preset", -1) ?: -1
        set(v) { sp()?.edit()?.putInt("eq_preset", v)?.apply() }

    var eqBass: Int // 0..1000 (BassBoost strength)
        get() = sp()?.getInt("eq_bass", 0) ?: 0
        set(v) { sp()?.edit()?.putInt("eq_bass", v)?.apply() }

    fun eqLevels(): List<Int> {
        val raw = sp()?.getString("eq_levels", "") ?: ""
        return if (raw.isEmpty()) emptyList() else raw.split(",").mapNotNull { it.toIntOrNull() }
    }

    fun saveEqLevels(levels: List<Int>) {
        sp()?.edit()?.putString("eq_levels", levels.joinToString(","))?.apply()
    }

    fun clearEq() {
        sp()?.edit()?.remove("eq_levels")?.remove("eq_preset")?.remove("eq_bass")?.apply()
    }

    // ---- playlists: stored as "name::id,id,id" entries joined by ";;" ----
    fun playlists(): List<Pair<String, List<Long>>> {
        val raw = sp()?.getString("playlists", "") ?: ""
        if (raw.isEmpty()) return emptyList()
        return raw.split(";;").mapNotNull { entry ->
            val parts = entry.split("::", limit = 2)
            if (parts.size < 2 || parts[0].isEmpty()) null
            else parts[0] to parts[1].split(",").mapNotNull { it.toLongOrNull() }
        }
    }

    private fun savePlaylists(list: List<Pair<String, List<Long>>>) {
        val raw = list.joinToString(";;") { (name, ids) -> "$name::${ids.joinToString(",")}" }
        sp()?.edit()?.putString("playlists", raw)?.apply()
    }

    private fun cleanName(name: String): String =
        name.replace(";", " ").replace(":", " ").trim().take(40)

    fun createPlaylist(name: String): Boolean {
        val n = cleanName(name)
        if (n.isEmpty()) return false
        val list = playlists().toMutableList()
        if (list.any { it.first.equals(n, ignoreCase = true) }) return false
        list.add(n to emptyList())
        savePlaylists(list)
        return true
    }

    fun renamePlaylist(old: String, newName: String): Boolean {
        val n = cleanName(newName)
        if (n.isEmpty()) return false
        val list = playlists().toMutableList()
        val i = list.indexOfFirst { it.first == old }
        if (i < 0) return false
        if (list.any { it.first.equals(n, ignoreCase = true) && it.first != old }) return false
        list[i] = n to list[i].second
        savePlaylists(list)
        return true
    }

    fun deletePlaylist(name: String) {
        savePlaylists(playlists().filter { it.first != name })
    }

    fun addToPlaylist(name: String, id: Long): Boolean {
        val list = playlists().toMutableList()
        val i = list.indexOfFirst { it.first == name }
        if (i < 0) return false
        val ids = list[i].second.toMutableList()
        if (ids.contains(id)) return false
        ids.add(id)
        list[i] = name to ids
        savePlaylists(list)
        return true
    }

    fun removeFromPlaylist(name: String, id: Long) {
        val list = playlists().toMutableList()
        val i = list.indexOfFirst { it.first == name }
        if (i < 0) return
        list[i] = name to list[i].second.filter { it != id }
        savePlaylists(list)
    }

    // ---- private folder (PIN + hidden ids) ----
    fun hiddenIds(): MutableSet<Long> {
        val raw = sp()?.getString("hidden_ids", "") ?: ""
        return if (raw.isEmpty()) mutableSetOf()
        else raw.split(",").mapNotNull { it.toLongOrNull() }.toMutableSet()
    }

    fun setHidden(id: Long, hidden: Boolean) {
        val set = hiddenIds()
        if (hidden) set.add(id) else set.remove(id)
        sp()?.edit()?.putString("hidden_ids", set.joinToString(","))?.apply()
    }

    fun hasPin(): Boolean = (sp()?.getString("pin_hash", "") ?: "").contains(":")

    fun setPin(pin: String) {
        val salt = ByteArray(16)
        java.security.SecureRandom().nextBytes(salt)
        val hash = pbkdf2(pin, salt)
        val enc = android.util.Base64.encodeToString(salt, android.util.Base64.NO_WRAP) + ":" +
            android.util.Base64.encodeToString(hash, android.util.Base64.NO_WRAP)
        sp()?.edit()?.putString("pin_hash", enc)?.apply()
    }

    fun verifyPin(pin: String): Boolean {
        val raw = sp()?.getString("pin_hash", "") ?: ""
        val parts = raw.split(":")
        if (parts.size != 2) return false
        return try {
            val salt = android.util.Base64.decode(parts[0], android.util.Base64.NO_WRAP)
            val expected = android.util.Base64.decode(parts[1], android.util.Base64.NO_WRAP)
            val actual = pbkdf2(pin, salt)
            java.security.MessageDigest.isEqual(expected, actual)
        } catch (e: Exception) { false }
    }

    fun clearPin() {
        sp()?.edit()?.remove("pin_hash")?.apply()
    }

    private fun pbkdf2(pin: String, salt: ByteArray): ByteArray {
        val spec = javax.crypto.spec.PBEKeySpec(pin.toCharArray(), salt, 60_000, 256)
        return javax.crypto.SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            .generateSecret(spec).encoded
    }
}
