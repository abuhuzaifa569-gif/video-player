package com.mylock.videoplayer

import android.app.Activity
import android.app.AlertDialog
import android.app.PictureInPictureParams
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.media.AudioManager
import android.media.MediaMetadataRetriever
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Rational
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.CheckBox
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import java.io.OutputStream
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlin.random.Random

@UnstableApi
class PlayerActivity : Activity() {

    companion object {
        const val EXTRA_IDS = "ids"
        const val EXTRA_INDEX = "index"
        const val EXTRA_URI = "uri"
        const val EXTRA_TITLE = "title"
        const val REQ_NOTIF = 9
    }

    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var controls: LinearLayout
    private lateinit var topBar: LinearLayout
    private lateinit var titleTxt: TextView
    private lateinit var timeTxt: TextView
    private lateinit var seekBar: SeekBar
    private lateinit var playBtn: TextView
    private lateinit var favBtn: TextView
    private lateinit var indicator: TextView
    private lateinit var unlockBtn: TextView
    private lateinit var previewTxt: TextView
    private lateinit var gestureLayer: View

    private var playlist: List<Video> = emptyList()
    private var index = 0
    private var externalUri: Uri? = null
    private var externalTitle: String = "Video"
    private var locked = false
    private var controlsVisible = true
    private var inPip = false
    private var manualOrientation = false

    // v2.0 state
    private var abA = -1L
    private var abB = -1L
    private var sleepEndAt = 0L
    private var zoomScale = 1.0f
    private var eq: Equalizer? = null
    private var bass: BassBoost? = null
    private var eqSession = 0

    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            try {
                updateProgress()
                saveResume()
                checkAbLoop()
                checkEqSession()
            } catch (e: Exception) { /* a bad tick must never kill playback */ }
            handler.postDelayed(this, 1000)
        }
    }
    private val hideControls = Runnable {
        if (player?.isPlaying == true && !locked) setControlsVisible(false)
    }
    private val sleepRunnable = Runnable {
        sleepEndAt = 0L
        player?.pause()
        stopBgService()
        toast("🌙 Sleep timer — playback stopped")
    }

    private fun currentVideo(): Video? = playlist.getOrNull(index)
    private fun currentUri(): Uri? = externalUri ?: currentVideo()?.uri
    private fun currentTitle(): String = externalUri?.let { externalTitle } ?: (currentVideo()?.title ?: "Video")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        Ui.applyTheme(Prefs.themeDark)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        buildUi()
        hideSystemBars()

        externalUri = intent.getStringExtra(EXTRA_URI)?.let { Uri.parse(it) }
        externalTitle = intent.getStringExtra(EXTRA_TITLE) ?: "Shared video"
        if (externalUri != null) {
            setupPlayer()
            loadCurrent(resume = false)
            return
        }
        val idsRaw = intent.getStringExtra(EXTRA_IDS) ?: ""
        val ids = idsRaw.split(",").mapNotNull { it.toLongOrNull() }
        index = intent.getIntExtra(EXTRA_INDEX, 0).coerceIn(0, maxOf(0, ids.size - 1))
        thread {
            val all = Library.loadVideos(this).associateBy { it.id }
            val list = ids.mapNotNull { all[it] }
            runOnUiThread {
                playlist = list
                if (index >= playlist.size) index = maxOf(0, playlist.size - 1)
                setupPlayer()
                loadCurrent(resume = true)
            }
        }
    }

    // ---------------- UI ----------------
    private fun buildUi() {
        val frame = FrameLayout(this)
        frame.setBackgroundColor(Color.BLACK)

        playerView = PlayerView(this)
        playerView.useController = false
        playerView.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
        frame.addView(playerView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        gestureLayer = View(this)
        gestureLayer.setOnTouchListener { _, ev -> onGestureTouch(ev) }
        frame.addView(gestureLayer, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        indicator = Ui.text(this, "", 20f, Color.WHITE, true)
        indicator.gravity = Gravity.CENTER
        indicator.setBackgroundColor(0xAA000000.toInt())
        indicator.setPadding(Ui.dp(this, 18), Ui.dp(this, 10), Ui.dp(this, 18), Ui.dp(this, 10))
        indicator.visibility = View.GONE
        val ilp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        ilp.gravity = Gravity.CENTER
        frame.addView(indicator, ilp)

        topBar = LinearLayout(this)
        topBar.orientation = LinearLayout.VERTICAL
        topBar.setBackgroundColor(0xB3000000.toInt())
        topBar.setPadding(Ui.dp(this, 14), Ui.dp(this, 10), Ui.dp(this, 14), Ui.dp(this, 6))
        val tlp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        tlp.gravity = Gravity.TOP
        frame.addView(topBar, tlp)

        controls = LinearLayout(this)
        controls.orientation = LinearLayout.VERTICAL
        controls.setBackgroundColor(0xB3000000.toInt())
        controls.setPadding(Ui.dp(this, 14), Ui.dp(this, 6), Ui.dp(this, 14), Ui.dp(this, 10))
        val clp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        clp.gravity = Gravity.BOTTOM
        frame.addView(controls, clp)

        val titleRow = LinearLayout(this)
        titleRow.orientation = LinearLayout.HORIZONTAL
        titleRow.gravity = Gravity.CENTER_VERTICAL
        titleTxt = Ui.text(this, "", 14f, Color.WHITE, true)
        titleTxt.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        titleRow.addView(titleTxt)
        favBtn = ctrlBtn("☆") {
            val v = currentVideo()
            if (v != null) {
                val now = Prefs.toggleFavorite(v.id)
                favBtn.text = if (now) "★" else "☆"
                toast(if (now) "Added to favorites" else "Removed from favorites")
            }
        }
        titleRow.addView(favBtn)
        titleRow.addView(ctrlBtn("🔒") { setLocked(true) })
        titleRow.addView(ctrlBtn("⧉") { enterPip() })
        titleRow.addView(ctrlBtn("☰") { showOptionsMenu() })
        topBar.addView(titleRow)

        // Seek preview label (v2.0) — shows the target time while dragging
        previewTxt = Ui.text(this, "", 13f, Ui.SECONDARY, true)
        previewTxt.gravity = Gravity.CENTER
        previewTxt.visibility = View.GONE
        controls.addView(previewTxt)

        val seekRow = LinearLayout(this)
        seekRow.orientation = LinearLayout.HORIZONTAL
        seekRow.gravity = Gravity.CENTER_VERTICAL
        timeTxt = Ui.text(this, "0:00 / 0:00", 12f, Color.WHITE)
        seekRow.addView(timeTxt)
        seekBar = SeekBar(this)
        seekBar.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        seekBar.max = 1000
        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    val dur = player?.duration ?: 0
                    if (dur > 0) {
                        val target = dur * progress / 1000
                        timeTxt.text = "${Library.fmtTime(target)} / ${Library.fmtTime(dur)}"
                        previewTxt.text = "⏩ Preview: ${Library.fmtTime(target)}"
                        previewTxt.visibility = View.VISIBLE
                    }
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar?) { handler.removeCallbacks(hideControls) }
            override fun onStopTrackingTouch(sb: SeekBar?) {
                val dur = player?.duration ?: 0
                if (dur > 0) player?.seekTo(dur * (sb?.progress ?: 0) / 1000)
                previewTxt.visibility = View.GONE
                scheduleHide()
            }
        })
        seekRow.addView(seekBar)
        controls.addView(seekRow)

        // Transport: Prev / BIG Play / Next in the center; Rotate in the corner.
        // v2.0 (Moiz): ALL buttons white, uniform medium size — play clearly bigger.
        val btnRow = FrameLayout(this)
        val playGroup = LinearLayout(this)
        playGroup.orientation = LinearLayout.HORIZONTAL
        playGroup.gravity = Gravity.CENTER
        playGroup.addView(ctrlBtn("⏮", 21f) { playOffset(-1) })
        playBtn = TextView(this)
        playBtn.text = "⏸"
        playBtn.textSize = 32f
        playBtn.setTextColor(Color.WHITE)
        playBtn.typeface = android.graphics.Typeface.DEFAULT_BOLD
        playBtn.setPadding(Ui.dp(this, 20), Ui.dp(this, 6), Ui.dp(this, 20), Ui.dp(this, 6))
        playBtn.setOnClickListener { togglePlay(); scheduleHide() }
        playGroup.addView(playBtn)
        playGroup.addView(ctrlBtn("⏭", 21f) { playOffset(1) })
        val glp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        glp.gravity = Gravity.CENTER
        btnRow.addView(playGroup, glp)
        val rlp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        rlp.gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
        btnRow.addView(ctrlBtn("🔄", 20f) { toggleOrientation() }, rlp)
        controls.addView(btnRow)

        unlockBtn = Ui.text(this, "🔓 Tap to unlock", 15f, Color.WHITE, true)
        unlockBtn.setBackgroundColor(0xAA000000.toInt())
        unlockBtn.setPadding(Ui.dp(this, 16), Ui.dp(this, 10), Ui.dp(this, 16), Ui.dp(this, 10))
        unlockBtn.visibility = View.GONE
        unlockBtn.setOnClickListener { setLocked(false) }
        val ulp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        ulp.gravity = Gravity.CENTER
        frame.addView(unlockBtn, ulp)

        setContentView(frame)
    }

    /** All player buttons are WHITE (v2.0). Default size is the uniform medium. */
    private fun ctrlBtn(label: String, sizeSp: Float = 19f, onClick: () -> Unit): TextView {
        val b = Ui.text(this, label, sizeSp, Color.WHITE)
        b.setPadding(Ui.dp(this, 12), Ui.dp(this, 8), Ui.dp(this, 12), Ui.dp(this, 8))
        b.setOnClickListener { onClick(); scheduleHide() }
        return b
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun hideSystemBars() {
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                window.setDecorFitsSystemWindows(false)
                window.insetsController?.hide(android.view.WindowInsets.Type.systemBars())
                window.insetsController?.systemBarsBehavior =
                    android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            } else {
                @Suppress("DEPRECATION")
                window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
            }
        } catch (e: Exception) { }
    }

    // ---------------- player ----------------
    private fun setupPlayer() {
        if (player != null) return
        val p = ExoPlayer.Builder(this).build()
        player = p
        playerView.player = p
        p.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_ENDED) onVideoEnded()
                updatePlayBtn()
            }
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                updatePlayBtn()
                refreshBgBar()
                if (isPlaying) scheduleHide() else handler.removeCallbacks(hideControls)
            }
            override fun onPlayerError(error: PlaybackException) {
                toast("Cannot play this video: ${error.errorCodeName}")
            }
            override fun onVideoSizeChanged(videoSize: VideoSize) {
                smartRotate(videoSize)
            }
        })
        p.setPlaybackSpeed(Prefs.lastSpeed)
        p.repeatMode = if (Prefs.repeatMode == 2) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
        // Bridge for the background player bar
        PlayerBridge.active = true
        PlayerBridge.isPlaying = { player?.isPlaying == true }
        PlayerBridge.onToggle = { runOnUiThread { togglePlay() } }
        PlayerBridge.onNext = { runOnUiThread { playOffset(1) } }
        PlayerBridge.onPrev = { runOnUiThread { playOffset(-1) } }
        PlayerBridge.onClose = {
            runOnUiThread {
                player?.pause()
                stopBgService()
            }
        }
        handler.post(tick)
    }

    private fun onVideoEnded() {
        currentVideo()?.let { Prefs.clearResume(it.id) }
        val p = player ?: return
        if (p.repeatMode == Player.REPEAT_MODE_ONE) return // native loop handles it
        if (externalUri != null) return
        if (playlist.size <= 1) return
        when {
            Prefs.shuffle -> {
                var n = index
                while (n == index) n = Random.nextInt(playlist.size)
                index = n
                loadCurrent(resume = true)
            }
            index < playlist.size - 1 -> { index++; loadCurrent(resume = true) }
            Prefs.repeatMode == 1 -> { index = 0; loadCurrent(resume = true) }
        }
    }

    /** Portrait videos play portrait, landscape videos landscape — unless the user rotated manually. */
    private fun smartRotate(vs: VideoSize) {
        try {
            if (manualOrientation || inPip) return
            if (vs.width <= 0 || vs.height <= 0) return
            val unpar = vs.width * vs.pixelWidthHeightRatio
            requestedOrientation = if (vs.height > unpar) ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            else ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        } catch (e: Exception) { }
    }

    private fun loadCurrent(resume: Boolean) {
        try {
            loadCurrentInner(resume)
        } catch (e: Exception) {
            toast("Could not play this video")
        }
    }

    private fun loadCurrentInner(resume: Boolean) {
        val uri = currentUri() ?: run { toast("Video not found"); return }
        val p = player ?: return
        titleTxt.text = currentTitle()
        PlayerBridge.title = currentTitle()
        val v = currentVideo()
        favBtn.text = if (v != null && Prefs.isFavorite(v.id)) "★" else "☆"
        if (v != null) Prefs.pushRecent(v.id)
        abA = -1L; abB = -1L
        zoomScale = 1.0f
        playerView.scaleX = 1f; playerView.scaleY = 1f
        p.setMediaItem(MediaItem.fromUri(uri))
        p.prepare()
        if (resume && v != null) {
            val pos = Prefs.resumePos(v.id)
            if (pos > 0) {
                p.seekTo(pos)
                toast("Resumed from ${Library.fmtTime(pos)}")
            }
        }
        p.playWhenReady = true
        setControlsVisible(true)
        scheduleHide()
        refreshBgBar()
        // Load the thumbnail for the background player bar
        if (v != null) {
            thread {
                val bmp = Library.thumbnail(this, v)
                if (bmp != null) {
                    PlayerBridge.thumb = bmp
                    refreshBgBar()
                }
            }
        } else {
            PlayerBridge.thumb = null
        }
    }

    private fun updateProgress() {
        val p = player ?: return
        val dur = p.duration
        val pos = p.currentPosition
        if (dur > 0) {
            seekBar.progress = (pos * 1000 / dur).toInt()
            timeTxt.text = "${Library.fmtTime(pos)} / ${Library.fmtTime(dur)}"
        }
    }

    private fun checkAbLoop() {
        val p = player ?: return
        if (abA >= 0 && abB > abA && p.currentPosition >= abB) {
            p.seekTo(abA)
        }
    }

    private fun saveResume() {
        val p = player ?: return
        val v = currentVideo() ?: return
        if (p.duration > 0) Prefs.saveResume(v.id, p.currentPosition, p.duration)
    }

    private fun updatePlayBtn() {
        playBtn.text = if (player?.isPlaying == true) "⏸" else "▶"
    }

    private fun togglePlay() {
        val p = player ?: return
        if (p.isPlaying) p.pause() else p.play()
        updatePlayBtn()
        refreshBgBar()
    }

    private fun playOffset(delta: Int) {
        if (externalUri != null) { toast("Only one video"); return }
        val n = index + delta
        if (n < 0 || n >= playlist.size) { toast(if (delta > 0) "Last video" else "First video"); return }
        saveResume()
        index = n
        loadCurrent(resume = true)
    }

    private fun setControlsVisible(show: Boolean) {
        controlsVisible = show
        val v = if (show && !locked) View.VISIBLE else View.GONE
        controls.visibility = v
        if (::topBar.isInitialized) topBar.visibility = v
    }

    // ---------------- options menu (v2.0, subtitles removed by Moiz's order) ----------------
    private fun showOptionsMenu() {
        val sleepLabel = if (sleepEndAt > 0) {
            val mins = ((sleepEndAt - android.os.SystemClock.elapsedRealtime()) / 60_000L).coerceAtLeast(0) + 1
            "🌙  Sleep timer (${mins} min left)"
        } else "🌙  Sleep timer (Off)"
        val repeatLabel = "🔂  Repeat: " + when (Prefs.repeatMode) { 1 -> "All"; 2 -> "One"; else -> "Off" }
        val shuffleLabel = "🔀  Shuffle: " + if (Prefs.shuffle) "On" else "Off"
        val bgLabel = "🎧  Background play: " + if (Prefs.bgPlay) "On" else "Off"
        val abLabel = when {
            abA >= 0 && abB > abA -> "🔁  A–B repeat: ON (${Library.fmtTime(abA)} → ${Library.fmtTime(abB)})"
            abA >= 0 -> "🔁  A–B repeat: A set, B pending…"
            else -> "🔁  A–B repeat"
        }
        val items = arrayOf(
            "⏩  Playback speed",
            "🔊  Audio track",
            "🎛  Equalizer",
            sleepLabel,
            abLabel,
            repeatLabel,
            shuffleLabel,
            "⏭  Double-tap skip: ${Prefs.tapSeekSeconds}s",
            "📸  Screenshot",
            bgLabel,
            "⬛  Resize (Fit / Fill / Zoom)"
        )
        AlertDialog.Builder(this)
            .setTitle("Options")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> showSpeedPicker()
                    1 -> showAudioPicker()
                    2 -> showEqualizer()
                    3 -> showSleepPicker()
                    4 -> showAbMenu()
                    5 -> cycleRepeat()
                    6 -> {
                        Prefs.shuffle = !Prefs.shuffle
                        toast("Shuffle " + if (Prefs.shuffle) "on" else "off")
                    }
                    7 -> showTapSeekPicker()
                    8 -> takeScreenshot()
                    9 -> toggleBgPlay()
                    10 -> cycleResize()
                }
                scheduleHide()
            }
            .show()
    }

    private fun cycleRepeat() {
        Prefs.repeatMode = (Prefs.repeatMode + 1) % 3
        player?.repeatMode = if (Prefs.repeatMode == 2) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
        toast("Repeat: " + when (Prefs.repeatMode) { 1 -> "All"; 2 -> "One"; else -> "Off" })
    }

    private fun showTapSeekPicker() {
        val opts = listOf(5, 10, 20, 30)
        val labels = opts.map { "${it} seconds" }.toTypedArray()
        val cur = opts.indexOf(Prefs.tapSeekSeconds).let { if (it < 0) 1 else it }
        AlertDialog.Builder(this)
            .setTitle("Double-tap skip")
            .setSingleChoiceItems(labels, cur) { d, which ->
                Prefs.tapSeekSeconds = opts[which]
                d.dismiss()
                toast("Double-tap skip: ${opts[which]}s")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showSleepPicker() {
        val opts = listOf(0, 15, 30, 45, 60)
        val labels = arrayOf("Off", "15 minutes", "30 minutes", "45 minutes", "60 minutes")
        AlertDialog.Builder(this)
            .setTitle("Sleep timer")
            .setItems(labels) { _, which ->
                handler.removeCallbacks(sleepRunnable)
                val mins = opts[which]
                if (mins > 0) {
                    sleepEndAt = android.os.SystemClock.elapsedRealtime() + mins * 60_000L
                    handler.postDelayed(sleepRunnable, mins * 60_000L)
                    toast("🌙 Playback will stop in $mins min")
                } else {
                    sleepEndAt = 0L
                    toast("Sleep timer off")
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showAbMenu() {
        val p = player ?: return
        val items = arrayOf(
            "Set A point (now: ${Library.fmtTime(p.currentPosition)})",
            "Set B point & loop",
            "Clear A–B"
        )
        AlertDialog.Builder(this)
            .setTitle("A–B Repeat")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> { abA = p.currentPosition; toast("A set at ${Library.fmtTime(abA)} — now set B") }
                    1 -> {
                        if (abA < 0) { toast("Set A first"); }
                        else if (p.currentPosition <= abA) { toast("B must be after A") }
                        else { abB = p.currentPosition; toast("🔁 Looping ${Library.fmtTime(abA)} → ${Library.fmtTime(abB)}") }
                    }
                    2 -> { abA = -1L; abB = -1L; toast("A–B cleared") }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---------------- equalizer ----------------
    private fun checkEqSession(force: Boolean = false) {
        // Lazy by design (v2.1): the device audio-effects engine is only touched
        // when the user has actually enabled the equalizer, or is opening its
        // dialog — never automatically in the background during playback.
        if (!force && !Prefs.eqEnabled) return
        val p = player ?: return
        try {
            val sid = p.audioSessionId
            if (sid != 0 && sid != eqSession) attachEq(sid)
        } catch (e: Exception) { }
    }

    private fun attachEq(sessionId: Int) {
        try {
            releaseEq()
            eqSession = sessionId
            val e = Equalizer(0, sessionId)
            val b = BassBoost(0, sessionId)
            eq = e
            bass = b
            applyEqFromPrefs()
        } catch (ex: Exception) {
            eq = null; bass = null
        }
    }

    private fun releaseEq() {
        try { eq?.release() } catch (e: Exception) { }
        try { bass?.release() } catch (e: Exception) { }
        eq = null; bass = null
        eqSession = 0
    }

    private fun applyEqFromPrefs() {
        val e = eq ?: return
        try {
            e.enabled = Prefs.eqEnabled
            val preset = Prefs.eqPreset
            if (preset >= 0) {
                try { e.usePreset(preset.toShort()) } catch (ex: Exception) { }
            } else {
                val levels = Prefs.eqLevels()
                val bands = e.numberOfBands.toInt()
                for (i in 0 until minOf(bands, levels.size)) {
                    try { e.setBandLevel(i.toShort(), levels[i].toShort()) } catch (ex: Exception) { }
                }
            }
            bass?.enabled = Prefs.eqEnabled
            try { bass?.setStrength(Prefs.eqBass.toShort()) } catch (ex: Exception) { }
        } catch (ex: Exception) { }
    }

    private fun showEqualizer() {
        val p = player ?: run { toast("Player not ready"); return }
        checkEqSession(force = true)
        val e = eq ?: run { toast("Equalizer not supported on this device"); return }
        val ctx = this
        val root = LinearLayout(ctx)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(Ui.dp(ctx, 18), Ui.dp(ctx, 12), Ui.dp(ctx, 18), Ui.dp(ctx, 8))

        val enableBox = CheckBox(ctx)
        enableBox.text = "Enable equalizer"
        enableBox.isChecked = Prefs.eqEnabled
        root.addView(enableBox)

        val presetBtn = Ui.text(ctx, "🎚 Presets…", 15f, Ui.SECONDARY, true)
        presetBtn.setPadding(0, Ui.dp(ctx, 10), 0, Ui.dp(ctx, 6))
        root.addView(presetBtn)

        val range = e.bandLevelRange // [min, max] millibels
        val min = range[0].toInt()
        val max = range[1].toInt()
        val bands = e.numberOfBands.toInt()
        val sliders = mutableListOf<SeekBar>()
        val valueLabels = mutableListOf<TextView>()
        for (i in 0 until bands) {
            val freq = try { e.getCenterFreq(i.toShort()) / 1000 } catch (ex: Exception) { 0 }
            val label = Ui.text(ctx, "Band ${i + 1} • ${freq} Hz", 12f, Ui.MUTED)
            root.addView(label)
            val row = LinearLayout(ctx)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            val sb = SeekBar(ctx)
            sb.max = max - min
            val cur = try { e.getBandLevel(i.toShort()).toInt() } catch (ex: Exception) { 0 }
            sb.progress = (cur - min).coerceIn(0, max - min)
            sb.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            val valTxt = Ui.text(ctx, "${(cur / 100.0)} dB", 12f, Ui.TEXT)
            valTxt.setPadding(Ui.dp(ctx, 8), 0, 0, 0)
            val bandIdx = i
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser) {
                        val level = min + progress
                        valTxt.text = "${(level / 100.0)} dB"
                        if (enableBox.isChecked) {
                            try { e.setBandLevel(bandIdx.toShort(), level.toShort()) } catch (ex: Exception) { }
                            Prefs.eqPreset = -1
                        }
                    }
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {
                    val levels = sliders.map { (it.progress + min) }
                    Prefs.saveEqLevels(levels)
                }
            })
            sliders.add(sb)
            valueLabels.add(valTxt)
            row.addView(sb)
            row.addView(valTxt)
            root.addView(row)
        }

        val bassLabel = Ui.text(ctx, "Bass boost", 12f, Ui.MUTED)
        bassLabel.setPadding(0, Ui.dp(ctx, 10), 0, 0)
        root.addView(bassLabel)
        val bassSb = SeekBar(ctx)
        bassSb.max = 1000
        bassSb.progress = Prefs.eqBass
        bassSb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    Prefs.eqBass = progress
                    if (enableBox.isChecked) {
                        try { bass?.setStrength(progress.toShort()) } catch (ex: Exception) { }
                    }
                }
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        root.addView(bassSb)

        presetBtn.setOnClickListener {
            try {
                val count = e.numberOfPresets.toInt()
                val names = (0 until count).map { e.getPresetName(it.toShort()) }.toTypedArray()
                AlertDialog.Builder(ctx)
                    .setTitle("Equalizer presets")
                    .setItems(names) { _, which ->
                        Prefs.eqPreset = which
                        if (enableBox.isChecked) {
                            try {
                                e.usePreset(which.toShort())
                                for (i in 0 until bands) {
                                    val lvl = e.getBandLevel(i.toShort()).toInt()
                                    sliders[i].progress = (lvl - min).coerceIn(0, max - min)
                                    valueLabels[i].text = "${(lvl / 100.0)} dB"
                                }
                            } catch (ex: Exception) { }
                        }
                        toast("Preset: ${names[which]}")
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            } catch (ex: Exception) {
                toast("No presets on this device")
            }
        }

        val scroll = ScrollView(ctx)
        scroll.addView(root)
        AlertDialog.Builder(ctx)
            .setTitle("🎛 Equalizer")
            .setView(scroll)
            .setPositiveButton("Done") { _, _ ->
                Prefs.eqEnabled = enableBox.isChecked
                applyEqFromPrefs()
            }
            .setNegativeButton("Cancel", null)
            .setOnDismissListener {
                // keep whatever is live-applied consistent with the saved levels
                val levels = sliders.map { it.progress + min }
                Prefs.saveEqLevels(levels)
            }
            .show()
    }

    // ---------------- background play + player bar ----------------
    private fun toggleBgPlay() {
        Prefs.bgPlay = !Prefs.bgPlay
        if (Prefs.bgPlay) {
            if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
            }
            toast("Background play ON — press Home: controls stay on the notification + lock screen bar")
            if (player?.isPlaying == true) startBgService()
        } else {
            toast("Background play OFF")
            stopBgService()
        }
    }

    private fun startBgService() {
        try {
            val i = Intent(this, PlayerService::class.java).setAction(PlayerService.ACTION_REFRESH)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        } catch (e: Exception) { }
    }

    private fun stopBgService() {
        try { stopService(Intent(this, PlayerService::class.java)) } catch (e: Exception) { }
    }

    private fun refreshBgBar() {
        if (PlayerService.running) startBgService()
    }

    // ---------------- screenshot ----------------
    private fun takeScreenshot() {
        val uri = currentUri() ?: run { toast("Nothing playing"); return }
        val posMs = player?.currentPosition ?: 0
        toast("📸 Saving screenshot…")
        thread {
            var ok = false
            try {
                val r = MediaMetadataRetriever()
                r.setDataSource(this, uri)
                val bmp = r.getFrameAtTime(posMs * 1000, MediaMetadataRetriever.OPTION_CLOSEST)
                try { r.release() } catch (e: Exception) { }
                if (bmp != null) {
                    val name = "VP_${System.currentTimeMillis()}.png"
                    val values = android.content.ContentValues().apply {
                        put(MediaStore.Images.Media.DISPLAY_NAME, name)
                        put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                        if (Build.VERSION.SDK_INT >= 29) {
                            put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/VideoPlayer")
                            put(MediaStore.Images.Media.IS_PENDING, 1)
                        }
                    }
                    val outUri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                    if (outUri != null) {
                        var os: OutputStream? = null
                        try {
                            os = contentResolver.openOutputStream(outUri)
                            ok = os != null && bmp.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, os)
                        } finally {
                            try { os?.close() } catch (e: Exception) { }
                        }
                        if (Build.VERSION.SDK_INT >= 29 && ok) {
                            val done = android.content.ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }
                            contentResolver.update(outUri, done, null, null)
                        }
                    }
                }
            } catch (e: Exception) { ok = false }
            runOnUiThread { toast(if (ok) "📸 Screenshot saved to Pictures/VideoPlayer" else "Screenshot failed for this video") }
        }
    }

    /** Portrait <-> landscape toggle (bottom corner). Manual choice wins over smart auto-rotate. */
    private fun toggleOrientation() {
        manualOrientation = true
        if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            toast("Portrait")
        } else {
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            toast("Landscape")
        }
    }

    private fun scheduleHide() {
        handler.removeCallbacks(hideControls)
        handler.postDelayed(hideControls, 3500)
    }

    private fun setLocked(lock: Boolean) {
        locked = lock
        if (lock) {
            setControlsVisible(false)
            unlockBtn.visibility = View.VISIBLE
            toast("Screen locked — controls hidden")
        } else {
            unlockBtn.visibility = View.GONE
            setControlsVisible(true)
            scheduleHide()
        }
    }

    private fun cycleResize() {
        val modes = listOf(
            AspectRatioFrameLayout.RESIZE_MODE_FIT to "Fit",
            AspectRatioFrameLayout.RESIZE_MODE_FILL to "Fill (crop sides)",
            AspectRatioFrameLayout.RESIZE_MODE_ZOOM to "Zoom"
        )
        val cur = modes.indexOfFirst { it.first == playerView.resizeMode }
        val next = modes[(cur + 1) % modes.size]
        playerView.resizeMode = next.first
        toast("Resize: ${next.second}")
    }

    private fun showSpeedPicker() {
        val speeds = listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f)
        val labels = speeds.map { "${it}×" }.toTypedArray()
        val cur = speeds.indexOf(Prefs.lastSpeed).let { if (it < 0) 2 else it }
        AlertDialog.Builder(this)
            .setTitle("Playback speed")
            .setSingleChoiceItems(labels, cur) { d, which ->
                val s = speeds[which]
                player?.setPlaybackSpeed(s)
                Prefs.lastSpeed = s
                d.dismiss()
                toast("Speed ${labels[which]}")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private data class TrackOption(val label: String, val group: Tracks.Group?, val trackIndex: Int)

    private fun trackOptions(type: Int): List<TrackOption> {
        val out = mutableListOf<TrackOption>()
        val tracks = player?.currentTracks ?: return out
        for (g in tracks.groups) {
            if (g.type != type) continue
            for (i in 0 until g.length) {
                if (!g.isTrackSupported(i)) continue
                val f = g.getTrackFormat(i)
                val lang = f.language ?: ""
                val name = f.label ?: lang.ifEmpty { "Track ${i + 1}" }
                val extra = listOfNotNull(
                    if (f.channelCount > 0) "${f.channelCount}ch" else null,
                    if (f.sampleRate > 0) "${f.sampleRate / 1000}kHz" else null
                ).joinToString(" ")
                out.add(TrackOption(if (extra.isEmpty()) name else "$name ($extra)", g, i))
            }
        }
        return out
    }

    private fun showAudioPicker() {
        val opts = trackOptions(C.TRACK_TYPE_AUDIO)
        if (opts.size <= 1) {
            toast(if (opts.isEmpty()) "No audio track info" else "Only one audio track in this video")
            return
        }
        val labels = opts.map { it.label }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Audio track")
            .setItems(labels) { _, which ->
                val p = player ?: return@setItems
                val o = opts[which]
                val g = o.group ?: return@setItems
                p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
                    .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, o.trackIndex))
                    .build()
                toast("Audio: ${o.label}")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun enterPip() {
        if (Build.VERSION.SDK_INT < 26) { toast("PiP needs Android 8+"); return }
        try {
            val fmt = player?.videoFormat
            val ratio = if (fmt != null && fmt.width > 0 && fmt.height > 0)
                Rational(fmt.width, fmt.height) else Rational(16, 9)
            val params = PictureInPictureParams.Builder().setAspectRatio(ratio).build()
            enterPictureInPictureMode(params)
        } catch (e: Exception) {
            toast("Picture-in-Picture not available")
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (Prefs.bgPlay) return // background bar takes over instead of PiP
        if (player?.isPlaying == true && Build.VERSION.SDK_INT >= 26) {
            try { enterPip() } catch (e: Exception) { }
        }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        inPip = isInPictureInPictureMode
        if (inPip) setControlsVisible(false) else { setControlsVisible(true); scheduleHide() }
    }

    // ---------------- gestures (incl. pinch zoom, v2.0) ----------------
    private var downX = 0f
    private var downY = 0f
    private var downTime = 0L
    private var gestureMode = 0 // 0 undecided, 1 horizontal seek, 2 vertical, 3 pinch
    private var startPosMs = 0L
    private var seekTargetMs = 0L
    private var startBrightness = 0.5f
    private var startVolume = 0
    private var maxVolume = 1
    private var lastTapTime = 0L
    private var lastTapX = 0f

    private val scaleDetector = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            gestureMode = 3
            zoomScale = (zoomScale * detector.scaleFactor).coerceIn(1.0f, 3.0f)
            playerView.scaleX = zoomScale
            playerView.scaleY = zoomScale
            showIndicator("🔍 Zoom ${(zoomScale * 100).toInt()}%")
            return true
        }
        override fun onScaleEnd(detector: ScaleGestureDetector) {
            hideIndicator()
            if (zoomScale <= 1.01f) {
                zoomScale = 1.0f
                playerView.scaleX = 1f
                playerView.scaleY = 1f
            }
        }
    })

    private fun showIndicator(text: String) {
        indicator.text = text
        indicator.visibility = View.VISIBLE
    }

    private fun hideIndicator() { indicator.visibility = View.GONE }

    private fun onGestureTouch(ev: MotionEvent): Boolean {
        if (locked || inPip) return true
        try { scaleDetector.onTouchEvent(ev) } catch (e: Exception) { }
        if (ev.pointerCount > 1) { gestureMode = 3; return true }
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = ev.x; downY = ev.y; downTime = System.currentTimeMillis()
                gestureMode = 0
                startPosMs = player?.currentPosition ?: 0
                seekTargetMs = startPosMs
                val lp = window.attributes
                startBrightness = if (lp.screenBrightness >= 0) lp.screenBrightness else 0.5f
                val am = getSystemService(AUDIO_SERVICE) as AudioManager
                startVolume = am.getStreamVolume(AudioManager.STREAM_MUSIC)
                maxVolume = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (gestureMode == 3) return true
                val dx = ev.x - downX
                val dy = ev.y - downY
                val w = gestureLayer.width.toFloat().coerceAtLeast(1f)
                val h = gestureLayer.height.toFloat().coerceAtLeast(1f)
                if (gestureMode == 0 && (abs(dx) > 24f || abs(dy) > 24f)) {
                    gestureMode = if (abs(dx) >= abs(dy)) 1 else 2
                }
                when (gestureMode) {
                    1 -> {
                        val delta = (dx / w * 90_000f).toLong()
                        val dur = player?.duration ?: 0
                        seekTargetMs = (startPosMs + delta).coerceIn(0, if (dur > 0) dur else Long.MAX_VALUE)
                        val sign = if (delta >= 0) "+" else "−"
                        showIndicator("⏩ ${Library.fmtTime(seekTargetMs)}\n(${sign}${Library.fmtTime(abs(delta))})")
                    }
                    2 -> {
                        val frac = -dy / h
                        if (downX < w / 2) {
                            val nb = (startBrightness + frac).coerceIn(0.01f, 1.0f)
                            val lp = window.attributes
                            lp.screenBrightness = nb
                            window.attributes = lp
                            showIndicator("☀ Brightness ${(nb * 100).toInt()}%")
                        } else {
                            val am = getSystemService(AUDIO_SERVICE) as AudioManager
                            val nv = (startVolume + frac * maxVolume).toInt().coerceIn(0, maxVolume)
                            am.setStreamVolume(AudioManager.STREAM_MUSIC, nv, 0)
                            showIndicator("🔊 Volume ${(nv * 100 / maxOf(1, maxVolume))}%")
                        }
                    }
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                hideIndicator()
                if (gestureMode == 1) {
                    player?.seekTo(seekTargetMs)
                    scheduleHide()
                } else if (gestureMode == 0) {
                    val now = System.currentTimeMillis()
                    val w = gestureLayer.width.toFloat().coerceAtLeast(1f)
                    val skipMs = Prefs.tapSeekSeconds * 1000L
                    if (now - lastTapTime < 300) {
                        if (ev.x < w / 3) {
                            player?.seekTo(maxOf(0, (player?.currentPosition ?: 0) - skipMs))
                            showIndicator("⏪ −${Prefs.tapSeekSeconds}s"); handler.postDelayed({ hideIndicator() }, 600)
                        } else if (ev.x > w * 2 / 3) {
                            player?.seekTo((player?.currentPosition ?: 0) + skipMs)
                            showIndicator("⏩ +${Prefs.tapSeekSeconds}s"); handler.postDelayed({ hideIndicator() }, 600)
                        } else {
                            togglePlay()
                        }
                        lastTapTime = 0L
                    } else {
                        lastTapTime = now
                        lastTapX = ev.x
                        handler.postDelayed({
                            if (lastTapTime == now) {
                                setControlsVisible(!controlsVisible)
                                if (controlsVisible) scheduleHide()
                                lastTapTime = 0L
                            }
                        }, 310)
                    }
                }
                gestureMode = 0
                return true
            }
        }
        return true
    }

    // ---------------- lifecycle ----------------
    override fun onPause() {
        super.onPause()
        saveResume()
        if (inPip) return
        if (Prefs.bgPlay && player?.isPlaying == true) {
            // Keep playing in the background with the player bar up
            startBgService()
        } else {
            player?.pause()
        }
    }

    override fun onResume() {
        super.onResume()
        hideSystemBars()
        // Back in the foreground: the bar is no longer needed
        if (PlayerService.running) stopBgService()
    }

    override fun onStop() {
        super.onStop()
        saveResume()
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        handler.removeCallbacks(hideControls)
        handler.removeCallbacks(sleepRunnable)
        saveResume()
        releaseEq()
        if (PlayerService.running) stopBgService()
        PlayerBridge.clear()
        player?.release()
        player = null
        super.onDestroy()
    }
}
