package com.mylock.videoplayer

import android.app.Activity
import android.app.AlertDialog
import android.app.PictureInPictureParams
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Rational
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import kotlin.concurrent.thread
import kotlin.math.abs

@UnstableApi
class PlayerActivity : Activity() {

    companion object {
        const val EXTRA_IDS = "ids"
        const val EXTRA_INDEX = "index"
        const val EXTRA_URI = "uri"
        const val EXTRA_TITLE = "title"
        const val REQ_SUBTITLE = 42
    }

    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var controls: LinearLayout
    private lateinit var topBar: LinearLayout
    private lateinit var titleTxt: TextView
    private lateinit var timeTxt: TextView
    private lateinit var seekBar: SeekBar
    private lateinit var playBtn: TextView
    private lateinit var favBtn: TextView
    private lateinit var indicator: TextView
    private lateinit var unlockBtn: TextView
    private lateinit var gestureLayer: View

    private var playlist: List<Video> = emptyList()
    private var index = 0
    private var externalUri: Uri? = null
    private var externalTitle: String = "Video"
    private var externalSub: Uri? = null
    private var externalSubName: String = ""
    private var locked = false
    private var controlsVisible = true
    private var inPip = false

    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            updateProgress()
            saveResume()
            handler.postDelayed(this, 1000)
        }
    }
    private val hideControls = Runnable {
        if (player?.isPlaying == true && !locked) setControlsVisible(false)
    }

    private fun currentVideo(): Video? = playlist.getOrNull(index)
    private fun currentUri(): Uri? = externalUri ?: currentVideo()?.uri
    private fun currentTitle(): String = externalUri?.let { externalTitle } ?: (currentVideo()?.title ?: "Video")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        buildUi()
        hideSystemBars()

        externalUri = intent.getStringExtra(EXTRA_URI)?.let { Uri.parse(it) }
        externalTitle = intent.getStringExtra(EXTRA_TITLE) ?: "Shared video"
        if (externalUri != null) {
            setupPlayer()
            loadCurrent(resume = false)
            return
        }
        val idsRaw = intent.getStringExtra(EXTRA_IDS) ?: ""
        val ids = idsRaw.split(",").mapNotNull { it.toLongOrNull() }
        index = intent.getIntExtra(EXTRA_INDEX, 0).coerceIn(0, maxOf(0, ids.size - 1))
        thread {
            val all = Library.loadVideos(this).associateBy { it.id }
            val list = ids.mapNotNull { all[it] }
            runOnUiThread {
                playlist = list
                // index was into the requested ids; clamp to resolved list
                if (index >= playlist.size) index = maxOf(0, playlist.size - 1)
                setupPlayer()
                loadCurrent(resume = true)
            }
        }
    }

    // ---------------- UI ----------------
    private fun buildUi() {
        val frame = FrameLayout(this)
        frame.setBackgroundColor(android.graphics.Color.BLACK)

        playerView = PlayerView(this)
        playerView.useController = false
        playerView.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
        frame.addView(playerView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        gestureLayer = View(this)
        gestureLayer.setOnTouchListener { _, ev -> onGestureTouch(ev) }
        frame.addView(gestureLayer, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        indicator = Ui.text(this, "", 20f, Ui.TEXT, true)
        indicator.gravity = Gravity.CENTER
        indicator.setBackgroundColor(0xAA000000.toInt())
        indicator.setPadding(Ui.dp(this, 18), Ui.dp(this, 10), Ui.dp(this, 18), Ui.dp(this, 10))
        indicator.visibility = View.GONE
        val ilp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        ilp.gravity = Gravity.CENTER
        frame.addView(indicator, ilp)

        // TOP bar: title + everything that is not playback (v1.1, Moiz's layout)
        topBar = LinearLayout(this)
        topBar.orientation = LinearLayout.VERTICAL
        topBar.setBackgroundColor(0xB3000000.toInt())
        topBar.setPadding(Ui.dp(this, 14), Ui.dp(this, 10), Ui.dp(this, 14), Ui.dp(this, 6))
        val tlp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        tlp.gravity = Gravity.TOP
        frame.addView(topBar, tlp)

        // BOTTOM bar: playback only — seek + play/prev/next + rotate in the corner
        controls = LinearLayout(this)
        controls.orientation = LinearLayout.VERTICAL
        controls.setBackgroundColor(0xB3000000.toInt())
        controls.setPadding(Ui.dp(this, 14), Ui.dp(this, 6), Ui.dp(this, 14), Ui.dp(this, 10))
        val clp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        clp.gravity = Gravity.BOTTOM
        frame.addView(controls, clp)

        val titleRow = LinearLayout(this)
        titleRow.orientation = LinearLayout.HORIZONTAL
        titleRow.gravity = Gravity.CENTER_VERTICAL
        titleTxt = Ui.text(this, "", 14f, Ui.TEXT, true)
        titleTxt.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        titleRow.addView(titleTxt)
        favBtn = ctrlBtn("☆") {
            val v = currentVideo()
            if (v != null) {
                val now = Prefs.toggleFavorite(v.id)
                favBtn.text = if (now) "★" else "☆"
                toast(if (now) "Added to favorites" else "Removed from favorites")
            }
        }
        titleRow.addView(favBtn)
        titleRow.addView(ctrlBtn("🔒") { setLocked(true) })
        titleRow.addView(ctrlBtn("⧉ PiP") { enterPip() })
        topBar.addView(titleRow)

        val optionsRow = LinearLayout(this)
        optionsRow.orientation = LinearLayout.HORIZONTAL
        optionsRow.gravity = Gravity.CENTER
        optionsRow.addView(ctrlBtn("⏩ Speed") { showSpeedPicker() })
        optionsRow.addView(ctrlBtn("💬 Sub") { showSubtitlePicker() })
        optionsRow.addView(ctrlBtn("🔊 Audio") { showAudioPicker() })
        optionsRow.addView(ctrlBtn("📂 Sub file") { pickSubtitleFile() })
        optionsRow.addView(ctrlBtn("⬛ Resize") { cycleResize() })
        topBar.addView(optionsRow)

        val seekRow = LinearLayout(this)
        seekRow.orientation = LinearLayout.HORIZONTAL
        seekRow.gravity = Gravity.CENTER_VERTICAL
        timeTxt = Ui.text(this, "0:00 / 0:00", 12f, Ui.TEXT)
        seekRow.addView(timeTxt)
        seekBar = SeekBar(this)
        seekBar.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        seekBar.max = 1000
        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    val dur = player?.duration ?: 0
                    if (dur > 0) {
                        val target = dur * progress / 1000
                        timeTxt.text = "${Library.fmtTime(target)} / ${Library.fmtTime(dur)}"
                    }
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar?) { handler.removeCallbacks(hideControls) }
            override fun onStopTrackingTouch(sb: SeekBar?) {
                val dur = player?.duration ?: 0
                if (dur > 0) player?.seekTo(dur * (sb?.progress ?: 0) / 1000)
                scheduleHide()
            }
        })
        seekRow.addView(seekBar)
        controls.addView(seekRow)

        val btnRow = LinearLayout(this)
        btnRow.orientation = LinearLayout.HORIZONTAL
        btnRow.gravity = Gravity.CENTER_VERTICAL
        btnRow.addView(ctrlBtn("⏮") { playOffset(-1) })
        playBtn = ctrlBtn("⏸") { togglePlay() }
        btnRow.addView(playBtn)
        btnRow.addView(ctrlBtn("⏭") { playOffset(1) })
        val spacer = View(this)
        spacer.layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
        btnRow.addView(spacer)
        // Portrait / landscape toggle — bottom corner (v1.1)
        btnRow.addView(ctrlBtn("🔄 Rotate") { toggleOrientation() })
        controls.addView(btnRow)

        unlockBtn = Ui.text(this, "🔓 Tap to unlock", 15f, Ui.TEXT, true)
        unlockBtn.setBackgroundColor(0xAA000000.toInt())
        unlockBtn.setPadding(Ui.dp(this, 16), Ui.dp(this, 10), Ui.dp(this, 16), Ui.dp(this, 10))
        unlockBtn.visibility = View.GONE
        unlockBtn.setOnClickListener { setLocked(false) }
        val ulp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        ulp.gravity = Gravity.CENTER
        frame.addView(unlockBtn, ulp)

        setContentView(frame)
    }

    private fun ctrlBtn(label: String, onClick: () -> Unit): TextView {
        val b = Ui.text(this, label, 14f, Ui.TEXT)
        b.setPadding(Ui.dp(this, 10), Ui.dp(this, 8), Ui.dp(this, 10), Ui.dp(this, 8))
        b.setOnClickListener { onClick(); scheduleHide() }
        return b
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun hideSystemBars() {
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                window.setDecorFitsSystemWindows(false)
                window.insetsController?.hide(android.view.WindowInsets.Type.systemBars())
                window.insetsController?.systemBarsBehavior =
                    android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            } else {
                @Suppress("DEPRECATION")
                window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
            }
        } catch (e: Exception) { }
    }

    // ---------------- player ----------------
    private fun setupPlayer() {
        if (player != null) return
        val p = ExoPlayer.Builder(this).build()
        player = p
        playerView.player = p
        p.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_ENDED) {
                    currentVideo()?.let { Prefs.clearResume(it.id) }
                    if (externalUri == null && index < playlist.size - 1) {
                        index++
                        loadCurrent(resume = true)
                    }
                }
                updatePlayBtn()
            }
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                updatePlayBtn()
                if (isPlaying) scheduleHide() else handler.removeCallbacks(hideControls)
            }
            override fun onPlayerError(error: PlaybackException) {
                toast("Cannot play this video: ${error.errorCodeName}")
            }
        })
        p.setPlaybackSpeed(Prefs.lastSpeed)
        handler.post(tick)
    }

    private fun buildMediaItem(uri: Uri): MediaItem {
        val b = MediaItem.Builder().setUri(uri)
        val sub = externalSub
        if (sub != null) {
            val cfg = MediaItem.SubtitleConfiguration.Builder(sub)
                .setMimeType(Library.subtitleMime(externalSubName))
                .setLanguage("und")
                .setLabel(externalSubName.ifEmpty { "External subtitle" })
                .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                .build()
            b.setSubtitleConfigurations(listOf(cfg))
        }
        return b.build()
    }

    private fun loadCurrent(resume: Boolean) {
        val uri = currentUri() ?: run { toast("Video not found"); return }
        val p = player ?: return
        titleTxt.text = currentTitle()
        val v = currentVideo()
        favBtn.text = if (v != null && Prefs.isFavorite(v.id)) "★" else "☆"
        if (v != null) Prefs.pushRecent(v.id)
        p.setMediaItem(buildMediaItem(uri))
        p.prepare()
        if (resume && v != null) {
            val pos = Prefs.resumePos(v.id)
            if (pos > 0) {
                p.seekTo(pos)
                toast("Resumed from ${Library.fmtTime(pos)}")
            }
        }
        p.playWhenReady = true
        setControlsVisible(true)
        scheduleHide()
    }

    private fun updateProgress() {
        val p = player ?: return
        val dur = p.duration
        val pos = p.currentPosition
        if (dur > 0) {
            seekBar.progress = (pos * 1000 / dur).toInt()
            timeTxt.text = "${Library.fmtTime(pos)} / ${Library.fmtTime(dur)}"
        }
    }

    private fun saveResume() {
        val p = player ?: return
        val v = currentVideo() ?: return
        if (p.duration > 0) Prefs.saveResume(v.id, p.currentPosition, p.duration)
    }

    private fun updatePlayBtn() {
        playBtn.text = if (player?.isPlaying == true) "⏸" else "▶"
    }

    private fun togglePlay() {
        val p = player ?: return
        if (p.isPlaying) p.pause() else p.play()
        updatePlayBtn()
    }

    private fun playOffset(delta: Int) {
        if (externalUri != null) { toast("Only one video"); return }
        val n = index + delta
        if (n < 0 || n >= playlist.size) { toast(if (delta > 0) "Last video" else "First video"); return }
        saveResume()
        index = n
        externalSub = null
        loadCurrent(resume = true)
    }

    private fun setControlsVisible(show: Boolean) {
        controlsVisible = show
        val v = if (show && !locked) View.VISIBLE else View.GONE
        controls.visibility = v
        if (::topBar.isInitialized) topBar.visibility = v
    }

    /** Portrait <-> landscape toggle for the bottom-corner Rotate button. */
    private fun toggleOrientation() {
        if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            toast("Portrait")
        } else {
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            toast("Landscape")
        }
    }

    private fun scheduleHide() {
        handler.removeCallbacks(hideControls)
        handler.postDelayed(hideControls, 3500)
    }

    private fun setLocked(lock: Boolean) {
        locked = lock
        if (lock) {
            setControlsVisible(false)
            unlockBtn.visibility = View.VISIBLE
            toast("Screen locked — controls hidden")
        } else {
            unlockBtn.visibility = View.GONE
            setControlsVisible(true)
            scheduleHide()
        }
    }

    private fun cycleResize() {
        val modes = listOf(
            AspectRatioFrameLayout.RESIZE_MODE_FIT to "Fit",
            AspectRatioFrameLayout.RESIZE_MODE_FILL to "Fill (crop sides)",
            AspectRatioFrameLayout.RESIZE_MODE_ZOOM to "Zoom"
        )
        val cur = modes.indexOfFirst { it.first == playerView.resizeMode }
        val next = modes[(cur + 1) % modes.size]
        playerView.resizeMode = next.first
        toast("Resize: ${next.second}")
    }

    private fun showSpeedPicker() {
        val speeds = listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f)
        val labels = speeds.map { "${it}×" }.toTypedArray()
        val cur = speeds.indexOf(Prefs.lastSpeed).let { if (it < 0) 2 else it }
        AlertDialog.Builder(this)
            .setTitle("Playback speed")
            .setSingleChoiceItems(labels, cur) { d, which ->
                val s = speeds[which]
                player?.setPlaybackSpeed(s)
                Prefs.lastSpeed = s
                d.dismiss()
                toast("Speed ${labels[which]}")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private data class TrackOption(val label: String, val group: Tracks.Group?, val trackIndex: Int, val disable: Boolean = false)

    private fun trackOptions(type: Int): List<TrackOption> {
        val out = mutableListOf<TrackOption>()
        val tracks = player?.currentTracks ?: return out
        for (g in tracks.groups) {
            if (g.type != type) continue
            for (i in 0 until g.length) {
                if (!g.isTrackSupported(i)) continue
                val f = g.getTrackFormat(i)
                val lang = f.language ?: ""
                val name = f.label ?: lang.ifEmpty { "Track ${i + 1}" }
                val extra = when (type) {
                    C.TRACK_TYPE_AUDIO -> listOfNotNull(
                        if (f.channelCount > 0) "${f.channelCount}ch" else null,
                        if (f.sampleRate > 0) "${f.sampleRate / 1000}kHz" else null
                    ).joinToString(" ")
                    C.TRACK_TYPE_TEXT -> f.codecs ?: ""
                    else -> ""
                }
                out.add(TrackOption(if (extra.isEmpty()) name else "$name ($extra)", g, i))
            }
        }
        return out
    }

    private fun showSubtitlePicker() {
        val opts = trackOptions(C.TRACK_TYPE_TEXT)
        if (opts.isEmpty()) {
            toast("No subtitle tracks in this video — use 📂 Sub file to load one")
            return
        }
        val labels = (listOf("Off") + opts.map { it.label }).toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Subtitles")
            .setItems(labels) { _, which ->
                val p = player ?: return@setItems
                if (which == 0) {
                    p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
                        .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true).build()
                    toast("Subtitles off")
                } else {
                    val o = opts[which - 1]
                    val g = o.group ?: return@setItems
                    p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
                        .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                        .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, o.trackIndex))
                        .build()
                    toast("Subtitle: ${o.label}")
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showAudioPicker() {
        val opts = trackOptions(C.TRACK_TYPE_AUDIO)
        if (opts.size <= 1) {
            toast(if (opts.isEmpty()) "No audio track info" else "Only one audio track in this video")
            return
        }
        val labels = opts.map { it.label }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Audio track")
            .setItems(labels) { _, which ->
                val p = player ?: return@setItems
                val o = opts[which]
                val g = o.group ?: return@setItems
                p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
                    .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, o.trackIndex))
                    .build()
                toast("Audio: ${o.label}")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun pickSubtitleFile() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        i.putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("text/*", "application/x-subrip", "*/*"))
        try {
            startActivityForResult(i, REQ_SUBTITLE)
        } catch (e: Exception) {
            toast("No file picker available")
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_SUBTITLE && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) { }
            externalSub = uri
            externalSubName = uri.lastPathSegment?.substringAfterLast('/') ?: "subtitle"
            val pos = player?.currentPosition ?: 0
            val uriNow = currentUri() ?: return
            player?.setMediaItem(buildMediaItem(uriNow))
            player?.prepare()
            player?.seekTo(pos)
            player?.playWhenReady = true
            toast("Subtitle loaded: $externalSubName")
        }
    }

    private fun enterPip() {
        if (Build.VERSION.SDK_INT < 26) { toast("PiP needs Android 8+"); return }
        try {
            val fmt = player?.videoFormat
            val ratio = if (fmt != null && fmt.width > 0 && fmt.height > 0)
                Rational(fmt.width, fmt.height) else Rational(16, 9)
            val params = PictureInPictureParams.Builder().setAspectRatio(ratio).build()
            enterPictureInPictureMode(params)
        } catch (e: Exception) {
            toast("Picture-in-Picture not available")
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (player?.isPlaying == true && Build.VERSION.SDK_INT >= 26) {
            try { enterPip() } catch (e: Exception) { }
        }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        inPip = isInPictureInPictureMode
        if (inPip) setControlsVisible(false) else { setControlsVisible(true); scheduleHide() }
    }

    // ---------------- gestures ----------------
    private var downX = 0f
    private var downY = 0f
    private var downTime = 0L
    private var gestureMode = 0 // 0 undecided, 1 horizontal seek, 2 vertical (bright/vol)
    private var startPosMs = 0L
    private var seekTargetMs = 0L
    private var startBrightness = 0.5f
    private var startVolume = 0
    private var maxVolume = 1
    private var lastTapTime = 0L
    private var lastTapX = 0f

    private fun showIndicator(text: String) {
        indicator.text = text
        indicator.visibility = View.VISIBLE
    }

    private fun hideIndicator() { indicator.visibility = View.GONE }

    private fun onGestureTouch(ev: MotionEvent): Boolean {
        if (locked || inPip) return true
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = ev.x; downY = ev.y; downTime = System.currentTimeMillis()
                gestureMode = 0
                startPosMs = player?.currentPosition ?: 0
                seekTargetMs = startPosMs
                val lp = window.attributes
                startBrightness = if (lp.screenBrightness >= 0) lp.screenBrightness else 0.5f
                val am = getSystemService(AUDIO_SERVICE) as AudioManager
                startVolume = am.getStreamVolume(AudioManager.STREAM_MUSIC)
                maxVolume = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = ev.x - downX
                val dy = ev.y - downY
                val w = gestureLayer.width.toFloat().coerceAtLeast(1f)
                val h = gestureLayer.height.toFloat().coerceAtLeast(1f)
                if (gestureMode == 0 && (abs(dx) > 24f || abs(dy) > 24f)) {
                    gestureMode = if (abs(dx) >= abs(dy)) 1 else 2
                }
                when (gestureMode) {
                    1 -> { // horizontal seek: full width ≈ 90 seconds
                        val delta = (dx / w * 90_000f).toLong()
                        val dur = player?.duration ?: 0
                        seekTargetMs = (startPosMs + delta).coerceIn(0, if (dur > 0) dur else Long.MAX_VALUE)
                        val sign = if (delta >= 0) "+" else "−"
                        showIndicator("⏩ ${Library.fmtTime(seekTargetMs)}\n(${sign}${Library.fmtTime(abs(delta))})")
                    }
                    2 -> { // vertical: left half brightness, right half volume
                        val frac = -dy / h // swipe up = positive
                        if (downX < w / 2) {
                            val nb = (startBrightness + frac).coerceIn(0.01f, 1.0f)
                            val lp = window.attributes
                            lp.screenBrightness = nb
                            window.attributes = lp
                            showIndicator("☀ Brightness ${(nb * 100).toInt()}%")
                        } else {
                            val am = getSystemService(AUDIO_SERVICE) as AudioManager
                            val nv = (startVolume + frac * maxVolume).toInt().coerceIn(0, maxVolume)
                            am.setStreamVolume(AudioManager.STREAM_MUSIC, nv, 0)
                            showIndicator("🔊 Volume ${(nv * 100 / maxOf(1, maxVolume))}%")
                        }
                    }
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                hideIndicator()
                if (gestureMode == 1) {
                    player?.seekTo(seekTargetMs)
                    scheduleHide()
                } else if (gestureMode == 0) {
                    // tap: distinguish double-tap (seek skip) from single tap (toggle controls)
                    val now = System.currentTimeMillis()
                    val w = gestureLayer.width.toFloat().coerceAtLeast(1f)
                    if (now - lastTapTime < 300) {
                        // double tap on a side zone
                        if (ev.x < w / 3) {
                            player?.seekTo(maxOf(0, (player?.currentPosition ?: 0) - 10_000))
                            showIndicator("⏪ −10s"); handler.postDelayed({ hideIndicator() }, 600)
                        } else if (ev.x > w * 2 / 3) {
                            player?.seekTo((player?.currentPosition ?: 0) + 10_000)
                            showIndicator("⏩ +10s"); handler.postDelayed({ hideIndicator() }, 600)
                        } else {
                            togglePlay()
                        }
                        lastTapTime = 0L
                    } else {
                        lastTapTime = now
                        lastTapX = ev.x
                        handler.postDelayed({
                            if (lastTapTime == now) {
                                setControlsVisible(!controlsVisible)
                                if (controlsVisible) scheduleHide()
                                lastTapTime = 0L
                            }
                        }, 310)
                    }
                }
                gestureMode = 0
                return true
            }
        }
        return true
    }

    // ---------------- lifecycle ----------------
    override fun onPause() {
        super.onPause()
        saveResume()
        if (!inPip) player?.pause()
    }

    override fun onResume() {
        super.onResume()
        hideSystemBars()
    }

    override fun onStop() {
        super.onStop()
        saveResume()
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        handler.removeCallbacks(hideControls)
        saveResume()
        player?.release()
        player = null
        super.onDestroy()
    }
}
