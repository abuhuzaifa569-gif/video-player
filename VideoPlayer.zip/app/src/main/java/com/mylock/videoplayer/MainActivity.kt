package com.mylock.videoplayer

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.GridView
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity() {

    companion object {
        const val TAB_ALL = 0
        const val TAB_FOLDERS = 1
        const val TAB_FAVORITES = 2
        const val TAB_RECENT = 3
        const val TAB_PLAYLISTS = 4
        const val TAB_PRIVATE = 5
        const val REQ_DELETE = 77
        val SORT_LABELS = arrayOf("Name A–Z", "Date (newest)", "Duration (longest)", "Size (largest)")
    }

    private var allVideos: List<Video> = emptyList()
    private var tab = TAB_ALL
    private var drillFolder: String? = null
    private var drillPlaylist: String? = null
    private var privateUnlocked = false
    private var query = ""

    private lateinit var listView: ListView
    private lateinit var gridView: GridView
    private lateinit var chipsRow: LinearLayout
    private lateinit var countTxt: TextView
    private lateinit var actionBtn: TextView
    private val thumbCache = HashMap<Long, Bitmap?>()
    private val thumbLoading = HashSet<Long>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        Ui.applyTheme(Prefs.themeDark)
        buildUi()
        if (intent?.action == Intent.ACTION_VIEW && intent.data != null) {
            val i = Intent(this, PlayerActivity::class.java)
            i.putExtra(PlayerActivity.EXTRA_URI, intent.data.toString())
            i.putExtra(PlayerActivity.EXTRA_TITLE, "Shared video")
            startActivity(i)
        }
        requestVideoPermission()
        loadLibrary()
        showCrashReportIfAny()
    }

    /** If the previous run crashed, show the saved trace so it can be reported. */
    private fun showCrashReportIfAny() {
        try {
            val f = java.io.File(filesDir, "last_crash.txt")
            if (!f.exists()) return
            val trace = f.readText()
            if (trace.isBlank()) return
            val tv = TextView(this)
            tv.text = trace
            tv.textSize = 11f
            tv.setTextColor(Ui.TEXT)
            tv.setPadding(Ui.dp(this, 16), Ui.dp(this, 8), Ui.dp(this, 16), Ui.dp(this, 8))
            val scroll = android.widget.ScrollView(this)
            scroll.addView(tv)
            AlertDialog.Builder(this)
                .setTitle("⚠ The app crashed last time")
                .setView(scroll)
                .setPositiveButton("Copy report") { _, _ ->
                    try {
                        val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                        cm.setPrimaryClip(android.content.ClipData.newPlainText("crash", trace))
                        toast("Report copied — you can paste it anywhere")
                    } catch (e: Exception) { }
                    f.delete()
                }
                .setNegativeButton("Dismiss") { _, _ -> f.delete() }
                .show()
        } catch (e: Exception) { }
    }

    override fun onResume() {
        super.onResume()
        if (allVideos.isNotEmpty()) refreshList()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun hasVideoPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= 33) {
            checkSelfPermission(Manifest.permission.READ_MEDIA_VIDEO) == PackageManager.PERMISSION_GRANTED ||
                checkSelfPermission(Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED) == PackageManager.PERMISSION_GRANTED
        } else {
            checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        }
    }

    private fun requestVideoPermission() {
        val perms = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33) {
            if (checkSelfPermission(Manifest.permission.READ_MEDIA_VIDEO) != PackageManager.PERMISSION_GRANTED)
                perms.add(Manifest.permission.READ_MEDIA_VIDEO)
            if (Build.VERSION.SDK_INT >= 34 &&
                checkSelfPermission(Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED) != PackageManager.PERMISSION_GRANTED)
                perms.add(Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED)
        } else if (!hasVideoPermission()) {
            perms.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        if (perms.isNotEmpty()) requestPermissions(perms.toTypedArray(), 7)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 7) loadLibrary()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_DELETE) {
            // Whether approved or not, rescan so the list matches the device
            loadLibrary()
            if (resultCode == RESULT_OK) toast("Video deleted")
        }
    }

    private fun loadLibrary() {
        thread {
            val vids = Library.loadVideos(this)
            runOnUiThread {
                allVideos = vids
                refreshList()
            }
        }
    }

    // ---------------- UI ----------------
    private fun buildUi() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Ui.BG)

        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        header.setPadding(Ui.dp(this, 16), Ui.dp(this, 12), Ui.dp(this, 8), Ui.dp(this, 6))
        val title = Ui.text(this, "🎬 Video Player", 20f, Ui.TEXT, true)
        title.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        header.addView(title)
        val themeBtn = TextView(this)
        themeBtn.text = if (Prefs.themeDark) "☀" else "🌙"
        themeBtn.textSize = 16f
        themeBtn.setPadding(Ui.dp(this, 8), Ui.dp(this, 8), Ui.dp(this, 8), Ui.dp(this, 8))
        themeBtn.setOnClickListener {
            Prefs.themeDark = !Prefs.themeDark
            toast(if (Prefs.themeDark) "Dark theme" else "Light theme")
            recreate()
        }
        header.addView(themeBtn)
        val viewBtn = TextView(this)
        viewBtn.text = if (Prefs.gridView) "☰ List" else "▦ Grid"
        viewBtn.setTextColor(Ui.SECONDARY)
        viewBtn.textSize = 13f
        viewBtn.setPadding(Ui.dp(this, 8), Ui.dp(this, 8), Ui.dp(this, 8), Ui.dp(this, 8))
        viewBtn.setOnClickListener {
            Prefs.gridView = !Prefs.gridView
            toast(if (Prefs.gridView) "Grid view" else "List view")
            recreate()
        }
        header.addView(viewBtn)
        val sortBtn = TextView(this)
        sortBtn.text = "↕ Sort"
        sortBtn.setTextColor(Ui.SECONDARY)
        sortBtn.textSize = 14f
        sortBtn.setPadding(Ui.dp(this, 10), Ui.dp(this, 8), Ui.dp(this, 10), Ui.dp(this, 8))
        sortBtn.setOnClickListener { showSortPicker() }
        header.addView(sortBtn)
        val testBtn = TextView(this)
        testBtn.text = "🧪"
        testBtn.textSize = 16f
        testBtn.setPadding(Ui.dp(this, 8), Ui.dp(this, 8), Ui.dp(this, 8), Ui.dp(this, 8))
        testBtn.setOnClickListener { startActivity(Intent(this, SelfTestActivity::class.java)) }
        header.addView(testBtn)
        root.addView(header)

        val search = EditText(this)
        search.hint = "Search videos, folders…"
        search.setHintTextColor(Ui.MUTED)
        search.setTextColor(Ui.TEXT)
        search.inputType = InputType.TYPE_CLASS_TEXT
        search.background = Ui.cardBg(12, Ui.SURFACE)
        search.setPadding(Ui.dp(this, 12), Ui.dp(this, 9), Ui.dp(this, 12), Ui.dp(this, 9))
        val slp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        slp.setMargins(Ui.dp(this, 14), Ui.dp(this, 4), Ui.dp(this, 14), Ui.dp(this, 6))
        search.layoutParams = slp
        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                query = s?.toString()?.trim()?.lowercase() ?: ""
                if (query.isNotEmpty()) {
                    tab = TAB_ALL; drillFolder = null; drillPlaylist = null
                    if (tab != TAB_PRIVATE) privateUnlocked = false
                    refreshChips()
                }
                refreshList()
            }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        root.addView(search)

        chipsRow = LinearLayout(this)
        chipsRow.orientation = LinearLayout.HORIZONTAL
        chipsRow.setPadding(Ui.dp(this, 10), Ui.dp(this, 4), Ui.dp(this, 10), Ui.dp(this, 4))
        val chipsScroll = HorizontalScrollView(this)
        chipsScroll.isHorizontalScrollBarEnabled = false
        chipsScroll.addView(chipsRow)
        root.addView(chipsScroll)
        refreshChips()

        countTxt = Ui.text(this, "", 12f, Ui.MUTED)
        countTxt.setPadding(Ui.dp(this, 16), Ui.dp(this, 2), Ui.dp(this, 16), Ui.dp(this, 4))
        root.addView(countTxt)

        actionBtn = Ui.text(this, "＋ New playlist", 13f, Ui.SECONDARY, true)
        actionBtn.setPadding(Ui.dp(this, 16), Ui.dp(this, 2), Ui.dp(this, 16), Ui.dp(this, 6))
        actionBtn.visibility = View.GONE
        actionBtn.setOnClickListener { promptNewPlaylist() }
        root.addView(actionBtn)

        listView = ListView(this)
        listView.divider = null
        listView.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        root.addView(listView)

        gridView = GridView(this)
        gridView.numColumns = 3
        gridView.horizontalSpacing = Ui.dp(this, 6)
        gridView.verticalSpacing = Ui.dp(this, 6)
        gridView.setPadding(Ui.dp(this, 8), Ui.dp(this, 4), Ui.dp(this, 8), Ui.dp(this, 4))
        gridView.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        gridView.visibility = View.GONE
        root.addView(gridView)

        setContentView(root)
        Ui.edgeToEdge(this, root)
    }

    private fun refreshChips() {
        chipsRow.removeAllViews()
        val labels = listOf("All Videos", "Folders", "★ Favorites", "Recent", "🎵 Playlists", "🔒 Private")
        for (i in labels.indices) {
            val chip = TextView(this)
            chip.text = labels[i]
            chip.textSize = 13f
            val active = tab == i && drillFolder == null && drillPlaylist == null
            chip.setTextColor(if (active) Ui.BG else Ui.TEXT)
            chip.background = if (active) Ui.gradientBtn(16) else Ui.cardBg(16, Ui.ELEVATED)
            chip.setPadding(Ui.dp(this, 12), Ui.dp(this, 7), Ui.dp(this, 12), Ui.dp(this, 7))
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.setMargins(Ui.dp(this, 4), 0, Ui.dp(this, 4), 0)
            chip.layoutParams = lp
            chip.setOnClickListener {
                if (i == TAB_PRIVATE && !privateUnlocked) {
                    authenticatePrivate {
                        tab = i; drillFolder = null; drillPlaylist = null
                        refreshChips(); refreshList()
                    }
                } else {
                    if (i != TAB_PRIVATE) privateUnlocked = false
                    tab = i; drillFolder = null; drillPlaylist = null
                    refreshChips(); refreshList()
                }
            }
            chipsRow.addView(chip)
        }
    }

    private fun showSortPicker() {
        AlertDialog.Builder(this)
            .setTitle("Sort videos by")
            .setSingleChoiceItems(SORT_LABELS, Prefs.sortMode) { d, which ->
                Prefs.sortMode = which
                d.dismiss()
                refreshList()
                toast("Sorted: ${SORT_LABELS[which]}")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---------------- private folder auth ----------------
    private fun pinField(hint: String): EditText {
        val e = EditText(this)
        e.hint = hint
        e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        e.setTextColor(Ui.TEXT)
        e.setHintTextColor(Ui.MUTED)
        return e
    }

    private fun authenticatePrivate(onOk: () -> Unit) {
        if (!Prefs.hasPin()) {
            val box = LinearLayout(this)
            box.orientation = LinearLayout.VERTICAL
            box.setPadding(Ui.dp(this, 20), Ui.dp(this, 8), Ui.dp(this, 20), 0)
            val p1 = pinField("Choose a PIN (4+ characters)")
            val p2 = pinField("Repeat the PIN")
            box.addView(p1)
            box.addView(p2)
            AlertDialog.Builder(this)
                .setTitle("🔒 Set your Private PIN")
                .setView(box)
                .setPositiveButton("Set PIN") { _, _ ->
                    val a = p1.text.toString()
                    val b = p2.text.toString()
                    when {
                        a.length < 4 -> toast("PIN too short — use at least 4 characters")
                        a != b -> toast("PINs do not match")
                        else -> {
                            Prefs.setPin(a)
                            privateUnlocked = true
                            toast("Private folder ready")
                            onOk()
                        }
                    }
                }
                .setNegativeButton("Cancel", null)
                .show()
        } else {
            val p = pinField("Enter your PIN")
            val box = LinearLayout(this)
            box.orientation = LinearLayout.VERTICAL
            box.setPadding(Ui.dp(this, 20), Ui.dp(this, 8), Ui.dp(this, 20), 0)
            box.addView(p)
            AlertDialog.Builder(this)
                .setTitle("🔒 Private folder")
                .setView(box)
                .setPositiveButton("Unlock") { _, _ ->
                    if (Prefs.verifyPin(p.text.toString())) {
                        privateUnlocked = true
                        onOk()
                    } else {
                        toast("Wrong PIN")
                    }
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    // ---------------- lists ----------------
    private fun publicVideos(): List<Video> {
        val hidden = Prefs.hiddenIds()
        return allVideos.filter { !hidden.contains(it.id) }
    }

    private fun visibleVideos(): List<Video> {
        val base = if (tab == TAB_PRIVATE && privateUnlocked) {
            val hidden = Prefs.hiddenIds()
            allVideos.filter { hidden.contains(it.id) }
        } else {
            publicVideos()
        }
        var list = when {
            drillFolder != null -> base.filter { it.folder == drillFolder }
            drillPlaylist != null -> {
                val byId = base.associateBy { it.id }
                val ids = Prefs.playlists().firstOrNull { it.first == drillPlaylist }?.second ?: emptyList()
                ids.mapNotNull { byId[it] }
            }
            tab == TAB_FAVORITES -> base.filter { Prefs.isFavorite(it.id) }
            tab == TAB_RECENT -> {
                val byId = base.associateBy { it.id }
                Prefs.recents().mapNotNull { byId[it] }
            }
            else -> base
        }
        if (query.isNotEmpty()) {
            list = list.filter {
                it.title.lowercase().contains(query) || it.folder.lowercase().contains(query)
            }
        }
        return if (tab == TAB_RECENT && drillFolder == null) list else Library.sortVideos(list, Prefs.sortMode)
    }

    private fun refreshList() {
        if (!::listView.isInitialized) return
        actionBtn.visibility = View.GONE
        // Folders home
        if (tab == TAB_FOLDERS && drillFolder == null && query.isEmpty()) {
            showListMode()
            val pub = publicVideos()
            val folders = pub.groupBy { it.folder }.entries
                .map { it.key to it.value }
                .sortedBy { it.first.lowercase() }
            countTxt.text = "${folders.size} folders • ${pub.size} videos"
            listView.adapter = FolderAdapter(folders)
            listView.setOnItemClickListener { _, _, pos, _ ->
                drillFolder = folders[pos].first
                refreshChips()
                refreshList()
            }
            listView.setOnItemLongClickListener(null)
            return
        }
        // Playlists home
        if (tab == TAB_PLAYLISTS && drillPlaylist == null && query.isEmpty()) {
            showListMode()
            actionBtn.visibility = View.VISIBLE
            val pls = Prefs.playlists()
            countTxt.text = "${pls.size} playlists"
            listView.adapter = PlaylistAdapter(pls)
            listView.setOnItemClickListener { _, _, pos, _ ->
                drillPlaylist = pls[pos].first
                refreshChips()
                refreshList()
            }
            listView.setOnItemLongClickListener { _, _, pos, _ ->
                showPlaylistMenu(pls[pos].first)
                true
            }
            return
        }
        val list = visibleVideos()
        countTxt.text = when {
            drillFolder != null -> "📁 $drillFolder — ${list.size} videos"
            drillPlaylist != null -> "🎵 $drillPlaylist — ${list.size} videos"
            tab == TAB_PRIVATE -> "🔒 Private — ${list.size} videos"
            !hasVideoPermission() -> "Allow video access to see your videos"
            list.isEmpty() && tab == TAB_FAVORITES -> "No favorites yet — tap ★ on any video"
            list.isEmpty() && tab == TAB_RECENT -> "Nothing played yet"
            list.isEmpty() && tab == TAB_PRIVATE -> "Private folder is empty — long-press any video → Move to Private"
            else -> "${list.size} videos"
        }
        if (Prefs.gridView) {
            listView.visibility = View.GONE
            gridView.visibility = View.VISIBLE
            gridView.adapter = VideoGridAdapter(list)
            gridView.setOnItemClickListener { _, _, pos, _ -> playVideo(list, pos) }
            gridView.setOnItemLongClickListener { _, _, pos, _ ->
                showVideoMenu(list[pos])
                true
            }
        } else {
            showListMode()
            listView.adapter = VideoAdapter(list)
            listView.setOnItemClickListener { _, _, pos, _ -> playVideo(list, pos) }
            listView.setOnItemLongClickListener { _, _, pos, _ ->
                showVideoMenu(list[pos])
                true
            }
        }
    }

    private fun showListMode() {
        gridView.visibility = View.GONE
        listView.visibility = View.VISIBLE
    }

    private fun playVideo(list: List<Video>, index: Int) {
        val v = list[index]
        Prefs.pushRecent(v.id)
        val i = Intent(this, PlayerActivity::class.java)
        i.putExtra(PlayerActivity.EXTRA_IDS, list.joinToString(",") { it.id.toString() })
        i.putExtra(PlayerActivity.EXTRA_INDEX, index)
        startActivity(i)
    }

    // ---------------- video + playlist actions ----------------
    private fun showVideoMenu(v: Video) {
        val isHidden = Prefs.hiddenIds().contains(v.id)
        val items = arrayOf(
            "▶  Play",
            "🎵  Add to playlist…",
            if (isHidden) "🔓  Remove from Private" else "🔒  Move to Private",
            "ℹ  Details",
            "↗  Share",
            "✏  Rename",
            "🗑  Delete"
        )
        AlertDialog.Builder(this)
            .setTitle(v.title)
            .setItems(items) { _, which ->
                when (which) {
                    0 -> {
                        val list = visibleVideos()
                        val idx = list.indexOfFirst { it.id == v.id }
                        if (idx >= 0) playVideo(list, idx)
                    }
                    1 -> showAddToPlaylist(v)
                    2 -> {
                        Prefs.setHidden(v.id, !isHidden)
                        toast(if (!isHidden) "Moved to Private 🔒" else "Removed from Private")
                        refreshList()
                    }
                    3 -> showDetails(v)
                    4 -> shareVideo(v)
                    5 -> renameVideo(v)
                    6 -> deleteVideo(v)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showAddToPlaylist(v: Video) {
        val pls = Prefs.playlists()
        if (pls.isEmpty()) {
            AlertDialog.Builder(this)
                .setTitle("No playlists yet")
                .setMessage("Create your first playlist to add this video.")
                .setPositiveButton("Create") { _, _ -> promptNewPlaylist(v) }
                .setNegativeButton("Cancel", null)
                .show()
            return
        }
        val names = pls.map { it.first }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Add to playlist")
            .setItems(names) { _, which ->
                val added = Prefs.addToPlaylist(names[which], v.id)
                toast(if (added) "Added to ${names[which]}" else "Already in ${names[which]}")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun promptNewPlaylist(thenAdd: Video? = null) {
        val input = EditText(this)
        input.hint = "Playlist name"
        input.setTextColor(Ui.TEXT)
        input.setHintTextColor(Ui.MUTED)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(Ui.dp(this, 20), Ui.dp(this, 8), Ui.dp(this, 20), 0)
        box.addView(input)
        AlertDialog.Builder(this)
            .setTitle("🎵 New playlist")
            .setView(box)
            .setPositiveButton("Create") { _, _ ->
                val name = input.text.toString()
                if (Prefs.createPlaylist(name)) {
                    toast("Playlist created")
                    if (thenAdd != null) {
                        val created = Prefs.playlists().lastOrNull()?.first
                        if (created != null) Prefs.addToPlaylist(created, thenAdd.id)
                    }
                    if (tab == TAB_PLAYLISTS) refreshList()
                } else {
                    toast("Name empty or already exists")
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showPlaylistMenu(name: String) {
        val items = arrayOf("✏  Rename", "🗑  Delete playlist")
        AlertDialog.Builder(this)
            .setTitle(name)
            .setItems(items) { _, which ->
                when (which) {
                    0 -> {
                        val input = EditText(this)
                        input.setText(name)
                        input.setTextColor(Ui.TEXT)
                        val box = LinearLayout(this)
                        box.orientation = LinearLayout.VERTICAL
                        box.setPadding(Ui.dp(this, 20), Ui.dp(this, 8), Ui.dp(this, 20), 0)
                        box.addView(input)
                        AlertDialog.Builder(this)
                            .setTitle("Rename playlist")
                            .setView(box)
                            .setPositiveButton("Rename") { _, _ ->
                                if (Prefs.renamePlaylist(name, input.text.toString())) {
                                    toast("Renamed")
                                    refreshList()
                                } else toast("Name empty or already exists")
                            }
                            .setNegativeButton("Cancel", null)
                            .show()
                    }
                    1 -> {
                        Prefs.deletePlaylist(name)
                        if (drillPlaylist == name) drillPlaylist = null
                        toast("Playlist deleted")
                        refreshList()
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showDetails(v: Video) {
        val df = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.US)
        val msg = "Name: ${v.title}\n" +
            "Folder: ${v.folder}\n" +
            "Duration: ${Library.fmtTime(v.duration)}\n" +
            "Resolution: ${v.resolution}\n" +
            "Size: ${Library.fmtSize(v.sizeBytes)}\n" +
            "Added: ${df.format(Date(v.dateAdded * 1000))}\n" +
            (if (v.path.isNotEmpty()) "Path: ${v.path}" else "")
        AlertDialog.Builder(this)
            .setTitle("ℹ Video details")
            .setMessage(msg)
            .setPositiveButton("OK", null)
            .show()
    }

    private fun shareVideo(v: Video) {
        try {
            val i = Intent(Intent.ACTION_SEND)
            i.type = "video/*"
            i.putExtra(Intent.EXTRA_STREAM, v.uri)
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(i, "Share video"))
        } catch (e: Exception) {
            toast("Sharing not available")
        }
    }

    private fun renameVideo(v: Video) {
        val input = EditText(this)
        input.setText(v.title)
        input.setTextColor(Ui.TEXT)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(Ui.dp(this, 20), Ui.dp(this, 8), Ui.dp(this, 20), 0)
        box.addView(input)
        AlertDialog.Builder(this)
            .setTitle("✏ Rename video")
            .setView(box)
            .setPositiveButton("Rename") { _, _ ->
                var name = input.text.toString().trim()
                if (name.isEmpty()) { toast("Name cannot be empty"); return@setPositiveButton }
                val ext = v.title.substringAfterLast('.', "")
                if (ext.isNotEmpty() && !name.contains('.')) name = "$name.$ext"
                try {
                    val values = android.content.ContentValues().apply {
                        put(MediaStore.Video.Media.DISPLAY_NAME, name)
                    }
                    val n = contentResolver.update(v.uri, values, null, null)
                    if (n > 0) { toast("Renamed"); loadLibrary() } else toast("Rename not allowed for this video")
                } catch (e: Exception) {
                    toast("Rename failed")
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun deleteVideo(v: Video) {
        AlertDialog.Builder(this)
            .setTitle("🗑 Delete video?")
            .setMessage("\"${v.title}\" will be deleted from your device. This cannot be undone.")
            .setPositiveButton("Delete") { _, _ ->
                try {
                    if (Build.VERSION.SDK_INT >= 30) {
                        val req = MediaStore.createDeleteRequest(contentResolver, listOf(v.uri))
                        startIntentSenderForResult(req.intentSender, REQ_DELETE, null, 0, 0, 0)
                    } else {
                        val n = contentResolver.delete(v.uri, null, null)
                        if (n > 0) { toast("Video deleted"); loadLibrary() } else toast("Delete not allowed")
                    }
                } catch (e: Exception) {
                    toast("Delete failed")
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---------------- adapters ----------------
    inner class FolderAdapter(private val folders: List<Pair<String, List<Video>>>) : BaseAdapter() {
        override fun getCount() = folders.size
        override fun getItem(pos: Int) = folders[pos]
        override fun getItemId(pos: Int) = pos.toLong()
        override fun getView(pos: Int, convertView: View?, parent: ViewGroup?): View {
            val ctx = this@MainActivity
            val (name, vids) = folders[pos]
            val totalDur = vids.sumOf { it.duration }
            val row = LinearLayout(ctx)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(Ui.dp(ctx, 16), Ui.dp(ctx, 12), Ui.dp(ctx, 16), Ui.dp(ctx, 12))
            row.background = Ui.cardBg(10, Ui.SURFACE)
            val icon = Ui.text(ctx, "📁", 26f, Ui.TEXT)
            icon.setPadding(0, 0, Ui.dp(ctx, 12), 0)
            row.addView(icon)
            val col = LinearLayout(ctx)
            col.orientation = LinearLayout.VERTICAL
            col.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            col.addView(Ui.text(ctx, name, 15f, Ui.TEXT, true))
            col.addView(Ui.text(ctx, "${vids.size} videos • ${Library.fmtTime(totalDur)} total", 12f, Ui.MUTED))
            row.addView(col)
            row.addView(Ui.text(ctx, "›", 22f, Ui.MUTED))
            return row
        }
    }

    inner class PlaylistAdapter(private val pls: List<Pair<String, List<Long>>>) : BaseAdapter() {
        override fun getCount() = pls.size
        override fun getItem(pos: Int) = pls[pos]
        override fun getItemId(pos: Int) = pos.toLong()
        override fun getView(pos: Int, convertView: View?, parent: ViewGroup?): View {
            val ctx = this@MainActivity
            val (name, ids) = pls[pos]
            val row = LinearLayout(ctx)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(Ui.dp(ctx, 16), Ui.dp(ctx, 12), Ui.dp(ctx, 16), Ui.dp(ctx, 12))
            row.background = Ui.cardBg(10, Ui.SURFACE)
            val icon = Ui.text(ctx, "🎵", 24f, Ui.TEXT)
            icon.setPadding(0, 0, Ui.dp(ctx, 12), 0)
            row.addView(icon)
            val col = LinearLayout(ctx)
            col.orientation = LinearLayout.VERTICAL
            col.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            col.addView(Ui.text(ctx, name, 15f, Ui.TEXT, true))
            col.addView(Ui.text(ctx, "${ids.size} videos  (long-press: rename / delete)", 12f, Ui.MUTED))
            row.addView(col)
            row.addView(Ui.text(ctx, "›", 22f, Ui.MUTED))
            return row
        }
    }

    private fun bindThumb(thumb: ImageView, v: Video) {
        val cached = thumbCache[v.id]
        if (cached != null) {
            thumb.setImageBitmap(cached)
        } else {
            thumb.setImageBitmap(null)
            if (!thumbLoading.contains(v.id)) {
                thumbLoading.add(v.id)
                thread {
                    val bmp = Library.thumbnail(this@MainActivity, v)
                    thumbCache[v.id] = bmp
                    thumbLoading.remove(v.id)
                    runOnUiThread {
                        if (::listView.isInitialized) (listView.adapter as? BaseAdapter)?.notifyDataSetChanged()
                        if (::gridView.isInitialized) (gridView.adapter as? BaseAdapter)?.notifyDataSetChanged()
                    }
                }
            }
        }
    }

    inner class VideoAdapter(private val videos: List<Video>) : BaseAdapter() {
        override fun getCount() = videos.size
        override fun getItem(pos: Int) = videos[pos]
        override fun getItemId(pos: Int) = videos[pos].id
        override fun getView(pos: Int, convertView: View?, parent: ViewGroup?): View {
            val ctx = this@MainActivity
            val v = videos[pos]
            val row = LinearLayout(ctx)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(Ui.dp(ctx, 12), Ui.dp(ctx, 8), Ui.dp(ctx, 8), Ui.dp(ctx, 8))
            row.background = Ui.cardBg(10, Ui.SURFACE)

            val thumb = ImageView(ctx)
            thumb.layoutParams = LinearLayout.LayoutParams(Ui.dp(ctx, 104), Ui.dp(ctx, 60))
            thumb.scaleType = ImageView.ScaleType.CENTER_CROP
            thumb.background = Ui.cardBg(8, Ui.ELEVATED)
            bindThumb(thumb, v)
            row.addView(thumb)

            val col = LinearLayout(ctx)
            col.orientation = LinearLayout.VERTICAL
            col.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            col.setPadding(Ui.dp(ctx, 10), 0, Ui.dp(ctx, 6), 0)
            val titleT = Ui.text(ctx, v.title, 14f, Ui.TEXT, true)
            titleT.maxLines = 2
            col.addView(titleT)
            val resume = Prefs.resumePos(v.id)
            val meta = "${Library.fmtTime(v.duration)} • ${v.resolution} • ${Library.fmtSize(v.sizeBytes)}" +
                (if (resume > 0) " • ▶ resume ${Library.fmtTime(resume)}" else "")
            col.addView(Ui.text(ctx, meta, 11.5f, Ui.MUTED))
            col.addView(Ui.text(ctx, "📁 ${v.folder}", 11.5f, Ui.MUTED))
            row.addView(col)

            val fav = TextView(ctx)
            fav.text = if (Prefs.isFavorite(v.id)) "★" else "☆"
            fav.setTextColor(if (Prefs.isFavorite(v.id)) Ui.GOLD else Ui.MUTED)
            fav.textSize = 22f
            fav.setPadding(Ui.dp(ctx, 8), Ui.dp(ctx, 8), Ui.dp(ctx, 8), Ui.dp(ctx, 8))
            fav.setOnClickListener {
                val now = Prefs.toggleFavorite(v.id)
                toast(if (now) "Added to favorites" else "Removed from favorites")
                refreshList()
            }
            row.addView(fav)
            return row
        }
    }

    inner class VideoGridAdapter(private val videos: List<Video>) : BaseAdapter() {
        override fun getCount() = videos.size
        override fun getItem(pos: Int) = videos[pos]
        override fun getItemId(pos: Int) = videos[pos].id
        override fun getView(pos: Int, convertView: View?, parent: ViewGroup?): View {
            val ctx = this@MainActivity
            val v = videos[pos]
            val cell = LinearLayout(ctx)
            cell.orientation = LinearLayout.VERTICAL
            cell.setPadding(Ui.dp(ctx, 4), Ui.dp(ctx, 4), Ui.dp(ctx, 4), Ui.dp(ctx, 6))
            cell.background = Ui.cardBg(10, Ui.SURFACE)
            val thumb = ImageView(ctx)
            thumb.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(ctx, 84))
            thumb.scaleType = ImageView.ScaleType.CENTER_CROP
            thumb.background = Ui.cardBg(8, Ui.ELEVATED)
            bindThumb(thumb, v)
            cell.addView(thumb)
            val t = Ui.text(ctx, v.title, 11.5f, Ui.TEXT, true)
            t.maxLines = 2
            t.setPadding(0, Ui.dp(ctx, 4), 0, 0)
            cell.addView(t)
            cell.addView(Ui.text(ctx, Library.fmtTime(v.duration), 10.5f, Ui.MUTED))
            return cell
        }
    }
}
