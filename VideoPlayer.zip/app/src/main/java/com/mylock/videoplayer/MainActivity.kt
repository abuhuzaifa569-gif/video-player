package com.mylock.videoplayer

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import kotlin.concurrent.thread

class MainActivity : Activity() {

    companion object {
        const val TAB_ALL = 0
        const val TAB_FOLDERS = 1
        const val TAB_FAVORITES = 2
        const val TAB_RECENT = 3
        val SORT_LABELS = arrayOf("Name A–Z", "Date (newest)", "Duration (longest)", "Size (largest)")
    }

    private var allVideos: List<Video> = emptyList()
    private var tab = TAB_ALL
    private var drillFolder: String? = null
    private var query = ""

    private lateinit var listView: ListView
    private lateinit var chipsRow: LinearLayout
    private lateinit var countTxt: TextView
    private val thumbCache = HashMap<Long, Bitmap?>()
    private val thumbLoading = HashSet<Long>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        buildUi()
        // Opened with a video from another app → play it straight away.
        if (intent?.action == Intent.ACTION_VIEW && intent.data != null) {
            val i = Intent(this, PlayerActivity::class.java)
            i.putExtra(PlayerActivity.EXTRA_URI, intent.data.toString())
            i.putExtra(PlayerActivity.EXTRA_TITLE, "Shared video")
            startActivity(i)
        }
        requestVideoPermission()
        loadLibrary()
    }

    override fun onResume() {
        super.onResume()
        if (allVideos.isNotEmpty()) refreshList()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun hasVideoPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= 33) {
            checkSelfPermission(Manifest.permission.READ_MEDIA_VIDEO) == PackageManager.PERMISSION_GRANTED ||
                checkSelfPermission(Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED) == PackageManager.PERMISSION_GRANTED
        } else {
            checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        }
    }

    private fun requestVideoPermission() {
        val perms = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33) {
            if (checkSelfPermission(Manifest.permission.READ_MEDIA_VIDEO) != PackageManager.PERMISSION_GRANTED)
                perms.add(Manifest.permission.READ_MEDIA_VIDEO)
            if (Build.VERSION.SDK_INT >= 34 &&
                checkSelfPermission(Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED) != PackageManager.PERMISSION_GRANTED)
                perms.add(Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED)
        } else if (!hasVideoPermission()) {
            perms.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        if (perms.isNotEmpty()) requestPermissions(perms.toTypedArray(), 7)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 7) loadLibrary()
    }

    private fun loadLibrary() {
        thread {
            val vids = Library.loadVideos(this)
            runOnUiThread {
                allVideos = vids
                refreshList()
            }
        }
    }

    // ---------------- UI ----------------
    private fun buildUi() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Ui.BG)

        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        header.setPadding(Ui.dp(this, 16), Ui.dp(this, 12), Ui.dp(this, 8), Ui.dp(this, 6))
        val title = Ui.text(this, "🎬 Video Player", 20f, Ui.TEXT, true)
        title.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        header.addView(title)
        val sortBtn = TextView(this)
        sortBtn.text = "↕ Sort"
        sortBtn.setTextColor(Ui.SECONDARY)
        sortBtn.textSize = 14f
        sortBtn.setPadding(Ui.dp(this, 10), Ui.dp(this, 8), Ui.dp(this, 10), Ui.dp(this, 8))
        sortBtn.setOnClickListener { showSortPicker() }
        header.addView(sortBtn)
        val testBtn = TextView(this)
        testBtn.text = "🧪"
        testBtn.textSize = 16f
        testBtn.setPadding(Ui.dp(this, 8), Ui.dp(this, 8), Ui.dp(this, 8), Ui.dp(this, 8))
        testBtn.setOnClickListener { startActivity(Intent(this, SelfTestActivity::class.java)) }
        header.addView(testBtn)
        root.addView(header)

        val search = EditText(this)
        search.hint = "Search videos, folders…"
        search.setHintTextColor(Ui.MUTED)
        search.setTextColor(Ui.TEXT)
        search.inputType = InputType.TYPE_CLASS_TEXT
        search.background = Ui.cardBg(12, Ui.SURFACE)
        search.setPadding(Ui.dp(this, 12), Ui.dp(this, 9), Ui.dp(this, 12), Ui.dp(this, 9))
        val slp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        slp.setMargins(Ui.dp(this, 14), Ui.dp(this, 4), Ui.dp(this, 14), Ui.dp(this, 6))
        search.layoutParams = slp
        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                query = s?.toString()?.trim()?.lowercase() ?: ""
                if (query.isNotEmpty()) { tab = TAB_ALL; drillFolder = null; refreshChips() }
                refreshList()
            }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        root.addView(search)

        chipsRow = LinearLayout(this)
        chipsRow.orientation = LinearLayout.HORIZONTAL
        chipsRow.setPadding(Ui.dp(this, 10), Ui.dp(this, 4), Ui.dp(this, 10), Ui.dp(this, 4))
        root.addView(chipsRow)
        refreshChips()

        countTxt = Ui.text(this, "", 12f, Ui.MUTED)
        countTxt.setPadding(Ui.dp(this, 16), Ui.dp(this, 2), Ui.dp(this, 16), Ui.dp(this, 4))
        root.addView(countTxt)

        listView = ListView(this)
        listView.divider = null
        listView.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        root.addView(listView)

        setContentView(root)
        Ui.edgeToEdge(this, root)
    }

    private fun refreshChips() {
        chipsRow.removeAllViews()
        val labels = listOf("All Videos", "Folders", "★ Favorites", "Recent")
        for (i in labels.indices) {
            val chip = TextView(this)
            chip.text = labels[i]
            chip.textSize = 13f
            val active = tab == i && drillFolder == null
            chip.setTextColor(if (active) Ui.BG else Ui.TEXT)
            chip.background = if (active) Ui.gradientBtn(16) else Ui.cardBg(16, Ui.ELEVATED)
            chip.setPadding(Ui.dp(this, 12), Ui.dp(this, 7), Ui.dp(this, 12), Ui.dp(this, 7))
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.setMargins(Ui.dp(this, 4), 0, Ui.dp(this, 4), 0)
            chip.layoutParams = lp
            chip.setOnClickListener { tab = i; drillFolder = null; refreshChips(); refreshList() }
            chipsRow.addView(chip)
        }
    }

    private fun showSortPicker() {
        AlertDialog.Builder(this)
            .setTitle("Sort videos by")
            .setSingleChoiceItems(SORT_LABELS, Prefs.sortMode) { d, which ->
                Prefs.sortMode = which
                d.dismiss()
                refreshList()
                toast("Sorted: ${SORT_LABELS[which]}")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    /** The list currently shown (after tab + folder-drill + search filtering). */
    private fun visibleVideos(): List<Video> {
        var list = when {
            drillFolder != null -> allVideos.filter { it.folder == drillFolder }
            tab == TAB_FAVORITES -> allVideos.filter { Prefs.isFavorite(it.id) }
            tab == TAB_RECENT -> {
                val byId = allVideos.associateBy { it.id }
                Prefs.recents().mapNotNull { byId[it] }
            }
            else -> allVideos
        }
        if (query.isNotEmpty()) {
            list = list.filter {
                it.title.lowercase().contains(query) || it.folder.lowercase().contains(query)
            }
        }
        return if (tab == TAB_RECENT && drillFolder == null) list else Library.sortVideos(list, Prefs.sortMode)
    }

    private fun refreshList() {
        if (!::listView.isInitialized) return
        if (tab == TAB_FOLDERS && drillFolder == null && query.isEmpty()) {
            val folders = allVideos.groupBy { it.folder }.entries
                .map { it.key to it.value }
                .sortedBy { it.first.lowercase() }
            countTxt.text = "${folders.size} folders • ${allVideos.size} videos"
            listView.adapter = FolderAdapter(folders)
            listView.setOnItemClickListener { _, _, pos, _ ->
                drillFolder = folders[pos].first
                refreshChips()
                refreshList()
            }
            return
        }
        val list = visibleVideos()
        countTxt.text = when {
            drillFolder != null -> "📁 $drillFolder — ${list.size} videos  (tap ⋮ back via Folders tab)"
            !hasVideoPermission() -> "Allow video access to see your videos"
            list.isEmpty() && tab == TAB_FAVORITES -> "No favorites yet — tap ★ on any video"
            list.isEmpty() && tab == TAB_RECENT -> "Nothing played yet"
            else -> "${list.size} videos"
        }
        listView.adapter = VideoAdapter(list)
        listView.setOnItemClickListener { _, _, pos, _ -> playVideo(list, pos) }
    }

    private fun playVideo(list: List<Video>, index: Int) {
        val v = list[index]
        Prefs.pushRecent(v.id)
        val i = Intent(this, PlayerActivity::class.java)
        i.putExtra(PlayerActivity.EXTRA_IDS, list.joinToString(",") { it.id.toString() })
        i.putExtra(PlayerActivity.EXTRA_INDEX, index)
        startActivity(i)
    }

    // ---------------- adapters ----------------
    inner class FolderAdapter(private val folders: List<Pair<String, List<Video>>>) : BaseAdapter() {
        override fun getCount() = folders.size
        override fun getItem(pos: Int) = folders[pos]
        override fun getItemId(pos: Int) = pos.toLong()
        override fun getView(pos: Int, convertView: View?, parent: ViewGroup?): View {
            val ctx = this@MainActivity
            val (name, vids) = folders[pos]
            val totalDur = vids.sumOf { it.duration }
            val row = LinearLayout(ctx)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(Ui.dp(ctx, 16), Ui.dp(ctx, 12), Ui.dp(ctx, 16), Ui.dp(ctx, 12))
            row.background = Ui.cardBg(10, Ui.SURFACE)
            val icon = Ui.text(ctx, "📁", 26f, Ui.TEXT)
            icon.setPadding(0, 0, Ui.dp(ctx, 12), 0)
            row.addView(icon)
            val col = LinearLayout(ctx)
            col.orientation = LinearLayout.VERTICAL
            col.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            col.addView(Ui.text(ctx, name, 15f, Ui.TEXT, true))
            col.addView(Ui.text(ctx, "${vids.size} videos • ${Library.fmtTime(totalDur)} total", 12f, Ui.MUTED))
            row.addView(col)
            row.addView(Ui.text(ctx, "›", 22f, Ui.MUTED))
            return row
        }
    }

    inner class VideoAdapter(private val videos: List<Video>) : BaseAdapter() {
        override fun getCount() = videos.size
        override fun getItem(pos: Int) = videos[pos]
        override fun getItemId(pos: Int) = videos[pos].id
        override fun getView(pos: Int, convertView: View?, parent: ViewGroup?): View {
            val ctx = this@MainActivity
            val v = videos[pos]
            val row = LinearLayout(ctx)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(Ui.dp(ctx, 12), Ui.dp(ctx, 8), Ui.dp(ctx, 8), Ui.dp(ctx, 8))
            row.background = Ui.cardBg(10, Ui.SURFACE)

            val thumb = ImageView(ctx)
            thumb.layoutParams = LinearLayout.LayoutParams(Ui.dp(ctx, 104), Ui.dp(ctx, 60))
            thumb.scaleType = ImageView.ScaleType.CENTER_CROP
            thumb.background = Ui.cardBg(8, Ui.ELEVATED)
            val cached = thumbCache[v.id]
            if (cached != null) {
                thumb.setImageBitmap(cached)
            } else {
                thumb.setImageBitmap(null)
                if (!thumbLoading.contains(v.id)) {
                    thumbLoading.add(v.id)
                    thread {
                        val bmp = Library.thumbnail(ctx, v)
                        thumbCache[v.id] = bmp
                        thumbLoading.remove(v.id)
                        runOnUiThread { notifyDataSetChanged() }
                    }
                }
            }
            row.addView(thumb)

            val col = LinearLayout(ctx)
            col.orientation = LinearLayout.VERTICAL
            col.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            col.setPadding(Ui.dp(ctx, 10), 0, Ui.dp(ctx, 6), 0)
            val titleT = Ui.text(ctx, v.title, 14f, Ui.TEXT, true)
            titleT.maxLines = 2
            col.addView(titleT)
            val resume = Prefs.resumePos(v.id)
            val meta = "${Library.fmtTime(v.duration)} • ${v.resolution} • ${Library.fmtSize(v.sizeBytes)}" +
                (if (resume > 0) " • ▶ resume ${Library.fmtTime(resume)}" else "")
            col.addView(Ui.text(ctx, meta, 11.5f, Ui.MUTED))
            col.addView(Ui.text(ctx, "📁 ${v.folder}", 11.5f, Ui.MUTED))
            row.addView(col)

            val fav = TextView(ctx)
            fav.text = if (Prefs.isFavorite(v.id)) "★" else "☆"
            fav.setTextColor(if (Prefs.isFavorite(v.id)) Ui.GOLD else Ui.MUTED)
            fav.textSize = 22f
            fav.setPadding(Ui.dp(ctx, 8), Ui.dp(ctx, 8), Ui.dp(ctx, 8), Ui.dp(ctx, 8))
            fav.setOnClickListener {
                val now = Prefs.toggleFavorite(v.id)
                toast(if (now) "Added to favorites" else "Removed from favorites")
                refreshList()
            }
            row.addView(fav)
            return row
        }
    }
}
