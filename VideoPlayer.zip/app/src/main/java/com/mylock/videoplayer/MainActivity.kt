package com.mylock.videoplayer

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.GridView
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity() {

    companion object {
        const val TAB_ALL = 0
        const val TAB_FOLDERS = 1
        const val TAB_FAVORITES = 2
        const val TAB_RECENT = 3
        const val TAB_PLAYLISTS = 4
        const val TAB_PRIVATE = 5
        const val REQ_DELETE = 77
        val SORT_LABELS = arrayOf("Name A–Z", "Date (newest)", "Duration (longest)", "Size (largest)")
    }

    private var allVideos: List<Video> = emptyList()
    private var tab = TAB_ALL
    private var drillFolder: String? = null
    private var drillPlaylist: String? = null
    private var privateUnlocked = false
    private var query = ""

    private lateinit var listView: ListView
    private lateinit var gridView: GridView
    private lateinit var chipsRow: LinearLayout
    private lateinit var countTxt: TextView
    private lateinit var actionBtn: TextView
    private lateinit var navBar: LinearLayout
    private val thumbCache = HashMap<Long, Bitmap?>()
    private val thumbLoading = HashSet<Long>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        Ui.applyTheme(Prefs.themeDark)
        buildUi()
        if (intent?.action == Intent.ACTION_VIEW && intent.data != null) {
            val i = Intent(this, PlayerActivity::class.java)
            i.putExtra(PlayerActivity.EXTRA_URI, intent.data.toString())
            i.putExtra(PlayerActivity.EXTRA_TITLE, "Shared video")
            startActivity(i)
        }
        requestVideoPermission()
        loadLibrary()
        showCrashReportIfAny()
    }

    /** If the previous run crashed, show the saved trace so it can be reported. */
    private fun showCrashReportIfAny() {
        try {
            val f = java.io.File(filesDir, "last_crash.txt")
            if (!f.exists()) return
            val trace = f.readText()
            if (trace.isBlank()) return
            val tv = TextView(this)
            tv.text = trace
            tv.textSize = 11f
            tv.setTextColor(Ui.TEXT)
            tv.setPadding(Ui.dp(this, 16), Ui.dp(this, 8), Ui.dp(this, 16), Ui.dp(this, 8))
            val scroll = android.widget.ScrollView(this)
            scroll.addView(tv)
            AlertDialog.Builder(this)
                .setTitle("⚠ The app crashed last time")
                .setView(scroll)
                .setPositiveButton("Copy report") { _, _ ->
                    try {
                        val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                        cm.setPrimaryClip(android.content.ClipData.newPlainText("crash", trace))
                        toast("Report copied — you can paste it anywhere")
                    } catch (e: Exception) { }
                    f.delete()
                }
                .setNegativeButton("Dismiss") { _, _ -> f.delete() }
                .show()
        } catch (e: Exception) { }
    }

    override fun onResume() {
        super.onResume()
        if (allVideos.isNotEmpty()) refreshList()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    /** Round header button (signature design): soft circle, centered glyph. */
    private fun roundBtn(label: String, onClick: () -> Unit): TextView {
        val b = TextView(this)
        b.text = label
        b.textSize = 16f
        b.setTextColor(Ui.TEXT)
        b.gravity = Gravity.CENTER
        b.background = Ui.circleBg(Ui.SURFACE)
        val lp = LinearLayout.LayoutParams(Ui.dp(this, 40), Ui.dp(this, 40))
        lp.setMargins(Ui.dp(this, 4), 0, Ui.dp(this, 4), 0)
        b.layoutParams = lp
        b.setOnClickListener { onClick() }
        return b
    }

    private fun hasVideoPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= 33) {
            checkSelfPermission(Manifest.permission.READ_MEDIA_VIDEO) == PackageManager.PERMISSION_GRANTED ||
                checkSelfPermission(Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED) == PackageManager.PERMISSION_GRANTED
        } else {
            checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        }
    }

    private fun requestVideoPermission() {
        val perms = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33) {
            if (checkSelfPermission(Manifest.permission.READ_MEDIA_VIDEO) != PackageManager.PERMISSION_GRANTED)
                perms.add(Manifest.permission.READ_MEDIA_VIDEO)
            if (Build.VERSION.SDK_INT >= 34 &&
                checkSelfPermission(Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED) != PackageManager.PERMISSION_GRANTED)
                perms.add(Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED)
        } else if (!hasVideoPermission()) {
            perms.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        if (perms.isNotEmpty()) requestPermissions(perms.toTypedArray(), 7)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 7) loadLibrary()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_DELETE) {
            // Whether approved or not, rescan so the list matches the device
            loadLibrary()
            if (resultCode == RESULT_OK) toast("Video deleted")
        }
    }

    private fun loadLibrary() {
        thread {
            val vids = Library.loadVideos(this)
            runOnUiThread {
                allVideos = vids
                refreshList()
            }
        }
    }

    // ---------------- UI ----------------
    private fun buildUi() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Ui.BG)

        // Signature top strip (crimson → orange)
        val topStrip = View(this)
        topStrip.background = Ui.gradientStrip()
        topStrip.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 5))
        root.addView(topStrip)

        // Header: app logo + two-tone title + ROUND buttons (Moiz's signature design)
        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        header.setPadding(Ui.dp(this, 14), Ui.dp(this, 12), Ui.dp(this, 12), Ui.dp(this, 8))
        val logo = ImageView(this)
        try { logo.setImageResource(R.mipmap.ic_launcher) } catch (e: Exception) { }
        logo.layoutParams = LinearLayout.LayoutParams(Ui.dp(this, 40), Ui.dp(this, 40))
        header.addView(logo)
        // Thin vertical divider between the logo and the title, like the mockups
        val logoDiv = View(this)
        logoDiv.setBackgroundColor(Ui.ELEVATED)
        val dlp = LinearLayout.LayoutParams(Ui.dp(this, 1), Ui.dp(this, 28))
        dlp.leftMargin = Ui.dp(this, 10)
        logoDiv.layoutParams = dlp
        header.addView(logoDiv)
        val titleBox = LinearLayout(this)
        titleBox.orientation = LinearLayout.HORIZONTAL
        titleBox.gravity = Gravity.CENTER_VERTICAL
        titleBox.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        titleBox.setPadding(Ui.dp(this, 10), 0, 0, 0)
        titleBox.addView(Ui.text(this, "Video ", 21f, Ui.TEXT, true))
        titleBox.addView(Ui.text(this, "Player", 21f, Ui.PRIMARY, true))
        header.addView(titleBox)
        header.addView(roundBtn(if (Prefs.themeDark) "☀" else "🌙") {
            Prefs.themeDark = !Prefs.themeDark
            toast(if (Prefs.themeDark) "Dark theme" else "Light theme")
            recreate()
        })
        header.addView(roundBtn(if (Prefs.gridView) "☰" else "▦") {
            Prefs.gridView = !Prefs.gridView
            toast(if (Prefs.gridView) "Grid view" else "List view")
            recreate()
        })
        header.addView(roundBtn("↕") { showSortPicker() })
        root.addView(header)

        // Search pill with a gradient end-piece (signature design)
        val searchBox = LinearLayout(this)
        searchBox.orientation = LinearLayout.HORIZONTAL
        searchBox.gravity = Gravity.CENTER_VERTICAL
        searchBox.background = Ui.cardBg(24, Ui.SURFACE)
        val sblp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        sblp.setMargins(Ui.dp(this, 14), Ui.dp(this, 4), Ui.dp(this, 14), Ui.dp(this, 6))
        searchBox.layoutParams = sblp
        val searchIcon = Ui.text(this, "🔍", 15f, Ui.MUTED)
        searchIcon.setPadding(Ui.dp(this, 14), 0, Ui.dp(this, 4), 0)
        searchBox.addView(searchIcon)
        val search = EditText(this)
        search.hint = "Search videos, folders…"
        search.setHintTextColor(Ui.MUTED)
        search.setTextColor(Ui.TEXT)
        search.inputType = InputType.TYPE_CLASS_TEXT
        search.setBackgroundColor(android.graphics.Color.TRANSPARENT)
        search.setPadding(Ui.dp(this, 2), Ui.dp(this, 10), Ui.dp(this, 6), Ui.dp(this, 10))
        search.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        searchBox.addView(search)
        val searchGo = Ui.text(this, "", 16f, android.graphics.Color.WHITE, true)
        searchGo.gravity = Gravity.CENTER
        searchGo.background = Ui.gradientBtn(20)
        val glp2 = LinearLayout.LayoutParams(Ui.dp(this, 52), Ui.dp(this, 38))
        glp2.setMargins(Ui.dp(this, 4), Ui.dp(this, 4), Ui.dp(this, 4), Ui.dp(this, 4))
        searchGo.layoutParams = glp2
        searchBox.addView(searchGo)
        root.addView(searchBox)
        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                query = s?.toString()?.trim()?.lowercase() ?: ""
                if (query.isNotEmpty()) {
                    tab = TAB_ALL; drillFolder = null; drillPlaylist = null
                    if (tab != TAB_PRIVATE) privateUnlocked = false
                    refreshChips()
                }
                refreshList()
            }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })

        chipsRow = LinearLayout(this)
        chipsRow.orientation = LinearLayout.HORIZONTAL
        chipsRow.setPadding(Ui.dp(this, 10), Ui.dp(this, 4), Ui.dp(this, 10), Ui.dp(this, 4))
        val chipsScroll = HorizontalScrollView(this)
        chipsScroll.isHorizontalScrollBarEnabled = false
        chipsScroll.addView(chipsRow)
        root.addView(chipsScroll)
        refreshChips()

        // Count line: bold count + hairline (signature design)
        val countRow = LinearLayout(this)
        countRow.orientation = LinearLayout.HORIZONTAL
        countRow.gravity = Gravity.CENTER_VERTICAL
        countRow.setPadding(Ui.dp(this, 16), Ui.dp(this, 4), Ui.dp(this, 16), Ui.dp(this, 4))
        countTxt = Ui.text(this, "", 15f, Ui.TEXT, true)
        countRow.addView(countTxt)
        val hairline = View(this)
        hairline.setBackgroundColor(Ui.ELEVATED)
        val hlp = LinearLayout.LayoutParams(0, Ui.dp(this, 1), 1f)
        hlp.setMargins(Ui.dp(this, 12), 0, 0, 0)
        hairline.layoutParams = hlp
        countRow.addView(hairline)
        root.addView(countRow)

        actionBtn = Ui.text(this, "＋ New playlist", 13f, Ui.SECONDARY, true)
        actionBtn.setPadding(Ui.dp(this, 16), Ui.dp(this, 2), Ui.dp(this, 16), Ui.dp(this, 6))
        actionBtn.visibility = View.GONE
        actionBtn.setOnClickListener { promptNewPlaylist() }
        root.addView(actionBtn)

        listView = ListView(this)
        listView.divider = null
        listView.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        root.addView(listView)

        gridView = GridView(this)
        gridView.numColumns = 3
        gridView.horizontalSpacing = Ui.dp(this, 6)
        gridView.verticalSpacing = Ui.dp(this, 6)
        gridView.setPadding(Ui.dp(this, 8), Ui.dp(this, 4), Ui.dp(this, 8), Ui.dp(this, 4))
        gridView.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        gridView.visibility = View.GONE
        root.addView(gridView)

        // Bottom navigation (signature design): Library / Folders / Favorites / Settings.
        // A raised sheet with big rounded top corners, like the mockups.
        navBar = LinearLayout(this)
        navBar.orientation = LinearLayout.HORIZONTAL
        navBar.gravity = Gravity.CENTER_VERTICAL
        val navBg = android.graphics.drawable.GradientDrawable()
        navBg.shape = android.graphics.drawable.GradientDrawable.RECTANGLE
        val nr = Ui.dp(this, 22).toFloat()
        navBg.cornerRadii = floatArrayOf(nr, nr, nr, nr, 0f, 0f, 0f, 0f)
        navBg.setColor(Ui.SURFACE)
        navBar.background = navBg
        navBar.elevation = Ui.dp(this, 10).toFloat()
        navBar.setPadding(Ui.dp(this, 8), Ui.dp(this, 8), Ui.dp(this, 8), Ui.dp(this, 10))
        root.addView(navBar)
        refreshNav()

        // Signature bottom strip
        val bottomStrip = View(this)
        bottomStrip.background = Ui.gradientStrip()
        bottomStrip.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 5))
        root.addView(bottomStrip)

        // Wave decoration behind the header (signature design), drawn once.
        val frame = android.widget.FrameLayout(this)
        val deco = android.widget.ImageView(this)
        deco.setImageBitmap(Ui.waveBitmap(1080, 340, Prefs.themeDark))
        deco.scaleType = android.widget.ImageView.ScaleType.FIT_XY
        deco.layoutParams = android.widget.FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 118)
        )
        frame.addView(deco)
        frame.addView(root, android.widget.FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ))
        setContentView(frame)
        Ui.edgeToEdge(this, root)
    }

    private fun navItem(icon: String, label: String, active: Boolean, onClick: () -> Unit): LinearLayout {
        val item = LinearLayout(this)
        item.orientation = LinearLayout.VERTICAL
        item.gravity = Gravity.CENTER
        item.setPadding(Ui.dp(this, 6), Ui.dp(this, 7), Ui.dp(this, 6), Ui.dp(this, 7))
        item.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        if (active) item.background = Ui.gradientBtn(18)
        val ic = Ui.text(this, icon, 19f, if (active) android.graphics.Color.WHITE else Ui.MUTED, true)
        ic.gravity = Gravity.CENTER
        item.addView(ic)
        val lb = Ui.text(this, label, 11f, if (active) android.graphics.Color.WHITE else Ui.MUTED, active)
        lb.gravity = Gravity.CENTER
        item.addView(lb)
        // Small gradient underline beneath the active item, like the mockups
        val under = View(this)
        if (active) under.background = Ui.gradientBtn(2)
        val up = LinearLayout.LayoutParams(Ui.dp(this, 26), Ui.dp(this, 3))
        up.topMargin = Ui.dp(this, 3)
        up.gravity = Gravity.CENTER_HORIZONTAL
        under.layoutParams = up
        item.addView(under)
        item.setOnClickListener { onClick() }
        return item
    }

    private fun navDivider(): View {
        val d = View(this)
        d.setBackgroundColor(Ui.ELEVATED)
        val p = LinearLayout.LayoutParams(Ui.dp(this, 1), Ui.dp(this, 28))
        p.gravity = Gravity.CENTER_VERTICAL
        p.leftMargin = Ui.dp(this, 4); p.rightMargin = Ui.dp(this, 4)
        d.layoutParams = p
        return d
    }

    private fun refreshNav() {
        if (!::navBar.isInitialized) return
        navBar.removeAllViews()
        navBar.addView(navItem("🎞", "Library", tab == TAB_ALL || tab == TAB_RECENT) {
            privateUnlocked = false
            tab = TAB_ALL; drillFolder = null; drillPlaylist = null
            refreshChips(); refreshList()
        })
        navBar.addView(navDivider())
        navBar.addView(navItem("📁", "Folders", tab == TAB_FOLDERS) {
            privateUnlocked = false
            tab = TAB_FOLDERS; drillFolder = null; drillPlaylist = null
            refreshChips(); refreshList()
        })
        navBar.addView(navDivider())
        navBar.addView(navItem("★", "Favorites", tab == TAB_FAVORITES) {
            privateUnlocked = false
            tab = TAB_FAVORITES; drillFolder = null; drillPlaylist = null
            refreshChips(); refreshList()
        })
        navBar.addView(navDivider())
        navBar.addView(navItem("⚙", "Settings", false) { showSettings() })
    }

    /** Thousands-grouped count, like the mockups ("1,915 videos"). */
    private fun fmtN(n: Int): String = String.format(java.util.Locale.US, "%,d", n)

    private fun showSettings() {
        val items = arrayOf(
            "🌗  Theme: " + if (Prefs.themeDark) "Dark" else "Light",
            "▦  View: " + if (Prefs.gridView) "Grid" else "List",
            "↕  Sort videos",
            "🧪  Auto Test",
            "ℹ  About (v2.4)"
        )
        AlertDialog.Builder(this)
            .setTitle("⚙ Settings")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> { Prefs.themeDark = !Prefs.themeDark; recreate() }
                    1 -> { Prefs.gridView = !Prefs.gridView; recreate() }
                    2 -> showSortPicker()
                    3 -> startActivity(Intent(this, SelfTestActivity::class.java))
                    4 -> AlertDialog.Builder(this)
                        .setTitle("🎬 Video Player v2.4")
                        .setMessage("Signature edition.\n100% offline — no internet permission.\nDark/Light themes, equalizer, background play bar, playlists, private folder.")
                        .setPositiveButton("OK", null)
                        .show()
                }
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun refreshChips() {
        chipsRow.removeAllViews()
        val labels = listOf("All Videos", "Folders", "★ Favorites", "Recent", "🎵 Playlists", "🔒 Private")
        for (i in labels.indices) {
            val chip = TextView(this)
            chip.text = labels[i]
            chip.textSize = 13f
            val active = tab == i && drillFolder == null && drillPlaylist == null
            chip.setTextColor(if (active) android.graphics.Color.WHITE else Ui.TEXT)
            chip.background = if (active) Ui.gradientBtn(16) else Ui.cardBg(16, Ui.ELEVATED)
            chip.setPadding(Ui.dp(this, 12), Ui.dp(this, 7), Ui.dp(this, 12), Ui.dp(this, 7))
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            chip.layoutParams = lp
            chip.setOnClickListener {
                if (i == TAB_PRIVATE && !privateUnlocked) {
                    authenticatePrivate {
                        tab = i; drillFolder = null; drillPlaylist = null
                        refreshChips(); refreshList()
                    }
                } else {
                    if (i != TAB_PRIVATE) privateUnlocked = false
                    tab = i; drillFolder = null; drillPlaylist = null
                    refreshChips(); refreshList()
                }
            }
            // Chip + small gradient underline (active only), like the mockups
            val wrap = LinearLayout(this)
            wrap.orientation = LinearLayout.VERTICAL
            wrap.gravity = Gravity.CENTER_HORIZONTAL
            val wlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            wlp.setMargins(Ui.dp(this, 4), 0, Ui.dp(this, 4), 0)
            wrap.layoutParams = wlp
            wrap.addView(chip)
            val under = View(this)
            if (active) under.background = Ui.gradientBtn(2)
            val up = LinearLayout.LayoutParams(Ui.dp(this, 26), Ui.dp(this, 3))
            up.topMargin = Ui.dp(this, 3)
            under.layoutParams = up
            wrap.addView(under)
            chipsRow.addView(wrap)
        }
        refreshNav()
    }

    private fun showSortPicker() {
        AlertDialog.Builder(this)
            .setTitle("Sort videos by")
            .setSingleChoiceItems(SORT_LABELS, Prefs.sortMode) { d, which ->
                Prefs.sortMode = which
                d.dismiss()
                refreshList()
                toast("Sorted: ${SORT_LABELS[which]}")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---------------- private folder auth ----------------
    private fun pinField(hint: String): EditText {
        val e = EditText(this)
        e.hint = hint
        e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        e.setTextColor(Ui.TEXT)
        e.setHintTextColor(Ui.MUTED)
        return e
    }

    private fun authenticatePrivate(onOk: () -> Unit) {
        if (!Prefs.hasPin()) {
            val box = LinearLayout(this)
            box.orientation = LinearLayout.VERTICAL
            box.setPadding(Ui.dp(this, 20), Ui.dp(this, 8), Ui.dp(this, 20), 0)
            val p1 = pinField("Choose a PIN (4+ characters)")
            val p2 = pinField("Repeat the PIN")
            box.addView(p1)
            box.addView(p2)
            AlertDialog.Builder(this)
                .setTitle("🔒 Set your Private PIN")
                .setView(box)
                .setPositiveButton("Set PIN") { _, _ ->
                    val a = p1.text.toString()
                    val b = p2.text.toString()
                    when {
                        a.length < 4 -> toast("PIN too short — use at least 4 characters")
                        a != b -> toast("PINs do not match")
                        else -> {
                            Prefs.setPin(a)
                            privateUnlocked = true
                            toast("Private folder ready")
                            onOk()
                        }
                    }
                }
                .setNegativeButton("Cancel", null)
                .show()
        } else {
            val p = pinField("Enter your PIN")
            val box = LinearLayout(this)
            box.orientation = LinearLayout.VERTICAL
            box.setPadding(Ui.dp(this, 20), Ui.dp(this, 8), Ui.dp(this, 20), 0)
            box.addView(p)
            AlertDialog.Builder(this)
                .setTitle("🔒 Private folder")
                .setView(box)
                .setPositiveButton("Unlock") { _, _ ->
                    if (Prefs.verifyPin(p.text.toString())) {
                        privateUnlocked = true
                        onOk()
                    } else {
                        toast("Wrong PIN")
                    }
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    // ---------------- lists ----------------
    private fun publicVideos(): List<Video> {
        val hidden = Prefs.hiddenIds()
        return allVideos.filter { !hidden.contains(it.id) }
    }

    private fun visibleVideos(): List<Video> {
        val base = if (tab == TAB_PRIVATE && privateUnlocked) {
            val hidden = Prefs.hiddenIds()
            allVideos.filter { hidden.contains(it.id) }
        } else {
            publicVideos()
        }
        var list = when {
            drillFolder != null -> base.filter { it.folder == drillFolder }
            drillPlaylist != null -> {
                val byId = base.associateBy { it.id }
                val ids = Prefs.playlists().firstOrNull { it.first == drillPlaylist }?.second ?: emptyList()
                ids.mapNotNull { byId[it] }
            }
            tab == TAB_FAVORITES -> base.filter { Prefs.isFavorite(it.id) }
            tab == TAB_RECENT -> {
                val byId = base.associateBy { it.id }
                Prefs.recents().mapNotNull { byId[it] }
            }
            else -> base
        }
        if (query.isNotEmpty()) {
            list = list.filter {
                it.title.lowercase().contains(query) || it.folder.lowercase().contains(query)
            }
        }
        return if (tab == TAB_RECENT && drillFolder == null) list else Library.sortVideos(list, Prefs.sortMode)
    }

    private fun refreshList() {
        if (!::listView.isInitialized) return
        actionBtn.visibility = View.GONE
        // Folders home
        if (tab == TAB_FOLDERS && drillFolder == null && query.isEmpty()) {
            showListMode()
            val pub = publicVideos()
            val folders = pub.groupBy { it.folder }.entries
                .map { it.key to it.value }
                .sortedBy { it.first.lowercase() }
            countTxt.text = "${fmtN(folders.size)} folders • ${fmtN(pub.size)} videos"
            listView.adapter = FolderAdapter(folders)
            listView.setOnItemClickListener { _, _, pos, _ ->
                drillFolder = folders[pos].first
                refreshChips()
                refreshList()
            }
            listView.setOnItemLongClickListener(null)
            return
        }
        // Playlists home
        if (tab == TAB_PLAYLISTS && drillPlaylist == null && query.isEmpty()) {
            showListMode()
            actionBtn.visibility = View.VISIBLE
            val pls = Prefs.playlists()
            countTxt.text = "${pls.size} playlists"
            listView.adapter = PlaylistAdapter(pls)
            listView.setOnItemClickListener { _, _, pos, _ ->
                drillPlaylist = pls[pos].first
                refreshChips()
                refreshList()
            }
            listView.setOnItemLongClickListener { _, _, pos, _ ->
                showPlaylistMenu(pls[pos].first)
                true
            }
            return
        }
        val list = visibleVideos()
        countTxt.text = when {
            drillFolder != null -> "📁 $drillFolder — ${list.size} videos"
            drillPlaylist != null -> "🎵 $drillPlaylist — ${list.size} videos"
            tab == TAB_PRIVATE -> "🔒 Private — ${list.size} videos"
            !hasVideoPermission() -> "Allow video access to see your videos"
            list.isEmpty() && tab == TAB_FAVORITES -> "No favorites yet — tap ★ on any video"
            list.isEmpty() && tab == TAB_RECENT -> "Nothing played yet"
            list.isEmpty() && tab == TAB_PRIVATE -> "Private folder is empty — long-press any video → Move to Private"
            else -> "${fmtN(list.size)} videos"
        }
        if (Prefs.gridView) {
            listView.visibility = View.GONE
            gridView.visibility = View.VISIBLE
            gridView.adapter = VideoGridAdapter(list)
            gridView.setOnItemClickListener { _, _, pos, _ -> playVideo(list, pos) }
            gridView.setOnItemLongClickListener { _, _, pos, _ ->
                showVideoMenu(list[pos])
                true
            }
        } else {
            showListMode()
            listView.adapter = VideoAdapter(list)
            listView.setOnItemClickListener { _, _, pos, _ -> playVideo(list, pos) }
            listView.setOnItemLongClickListener { _, _, pos, _ ->
                showVideoMenu(list[pos])
                true
            }
        }
    }

    private fun showListMode() {
        gridView.visibility = View.GONE
        listView.visibility = View.VISIBLE
    }

    private fun playVideo(list: List<Video>, index: Int) {
        val v = list[index]
        Prefs.pushRecent(v.id)
        val i = Intent(this, PlayerActivity::class.java)
        i.putExtra(PlayerActivity.EXTRA_IDS, list.joinToString(",") { it.id.toString() })
        i.putExtra(PlayerActivity.EXTRA_INDEX, index)
        startActivity(i)
    }

    // ---------------- video + playlist actions ----------------
    private fun showVideoMenu(v: Video) {
        val isHidden = Prefs.hiddenIds().contains(v.id)
        val items = arrayOf(
            "▶  Play",
            "🎵  Add to playlist…",
            if (isHidden) "🔓  Remove from Private" else "🔒  Move to Private",
            "ℹ  Details",
            "↗  Share",
            "✏  Rename",
            "🗑  Delete"
        )
        AlertDialog.Builder(this)
            .setTitle(v.title)
            .setItems(items) { _, which ->
                when (which) {
                    0 -> {
                        val list = visibleVideos()
                        val idx = list.indexOfFirst { it.id == v.id }
                        if (idx >= 0) playVideo(list, idx)
                    }
                    1 -> showAddToPlaylist(v)
                    2 -> {
                        Prefs.setHidden(v.id, !isHidden)
                        toast(if (!isHidden) "Moved to Private 🔒" else "Removed from Private")
                        refreshList()
                    }
                    3 -> showDetails(v)
                    4 -> shareVideo(v)
                    5 -> renameVideo(v)
                    6 -> deleteVideo(v)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showAddToPlaylist(v: Video) {
        val pls = Prefs.playlists()
        if (pls.isEmpty()) {
            AlertDialog.Builder(this)
                .setTitle("No playlists yet")
                .setMessage("Create your first playlist to add this video.")
                .setPositiveButton("Create") { _, _ -> promptNewPlaylist(v) }
                .setNegativeButton("Cancel", null)
                .show()
            return
        }
        val names = pls.map { it.first }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Add to playlist")
            .setItems(names) { _, which ->
                val added = Prefs.addToPlaylist(names[which], v.id)
                toast(if (added) "Added to ${names[which]}" else "Already in ${names[which]}")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun promptNewPlaylist(thenAdd: Video? = null) {
        val input = EditText(this)
        input.hint = "Playlist name"
        input.setTextColor(Ui.TEXT)
        input.setHintTextColor(Ui.MUTED)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(Ui.dp(this, 20), Ui.dp(this, 8), Ui.dp(this, 20), 0)
        box.addView(input)
        AlertDialog.Builder(this)
            .setTitle("🎵 New playlist")
            .setView(box)
            .setPositiveButton("Create") { _, _ ->
                val name = input.text.toString()
                if (Prefs.createPlaylist(name)) {
                    toast("Playlist created")
                    if (thenAdd != null) {
                        val created = Prefs.playlists().lastOrNull()?.first
                        if (created != null) Prefs.addToPlaylist(created, thenAdd.id)
                    }
                    if (tab == TAB_PLAYLISTS) refreshList()
                } else {
                    toast("Name empty or already exists")
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showPlaylistMenu(name: String) {
        val items = arrayOf("✏  Rename", "🗑  Delete playlist")
        AlertDialog.Builder(this)
            .setTitle(name)
            .setItems(items) { _, which ->
                when (which) {
                    0 -> {
                        val input = EditText(this)
                        input.setText(name)
                        input.setTextColor(Ui.TEXT)
                        val box = LinearLayout(this)
                        box.orientation = LinearLayout.VERTICAL
                        box.setPadding(Ui.dp(this, 20), Ui.dp(this, 8), Ui.dp(this, 20), 0)
                        box.addView(input)
                        AlertDialog.Builder(this)
                            .setTitle("Rename playlist")
                            .setView(box)
                            .setPositiveButton("Rename") { _, _ ->
                                if (Prefs.renamePlaylist(name, input.text.toString())) {
                                    toast("Renamed")
                                    refreshList()
                                } else toast("Name empty or already exists")
                            }
                            .setNegativeButton("Cancel", null)
                            .show()
                    }
                    1 -> {
                        Prefs.deletePlaylist(name)
                        if (drillPlaylist == name) drillPlaylist = null
                        toast("Playlist deleted")
                        refreshList()
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showDetails(v: Video) {
        val df = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.US)
        val msg = "Name: ${v.title}\n" +
            "Folder: ${v.folder}\n" +
            "Duration: ${Library.fmtTime(v.duration)}\n" +
            "Resolution: ${v.resolution}\n" +
            "Size: ${Library.fmtSize(v.sizeBytes)}\n" +
            "Added: ${df.format(Date(v.dateAdded * 1000))}\n" +
            (if (v.path.isNotEmpty()) "Path: ${v.path}" else "")
        AlertDialog.Builder(this)
            .setTitle("ℹ Video details")
            .setMessage(msg)
            .setPositiveButton("OK", null)
            .show()
    }

    private fun shareVideo(v: Video) {
        try {
            val i = Intent(Intent.ACTION_SEND)
            i.type = "video/*"
            i.putExtra(Intent.EXTRA_STREAM, v.uri)
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(i, "Share video"))
        } catch (e: Exception) {
            toast("Sharing not available")
        }
    }

    private fun renameVideo(v: Video) {
        val input = EditText(this)
        input.setText(v.title)
        input.setTextColor(Ui.TEXT)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(Ui.dp(this, 20), Ui.dp(this, 8), Ui.dp(this, 20), 0)
        box.addView(input)
        AlertDialog.Builder(this)
            .setTitle("✏ Rename video")
            .setView(box)
            .setPositiveButton("Rename") { _, _ ->
                var name = input.text.toString().trim()
                if (name.isEmpty()) { toast("Name cannot be empty"); return@setPositiveButton }
                val ext = v.title.substringAfterLast('.', "")
                if (ext.isNotEmpty() && !name.contains('.')) name = "$name.$ext"
                try {
                    val values = android.content.ContentValues().apply {
                        put(MediaStore.Video.Media.DISPLAY_NAME, name)
                    }
                    val n = contentResolver.update(v.uri, values, null, null)
                    if (n > 0) { toast("Renamed"); loadLibrary() } else toast("Rename not allowed for this video")
                } catch (e: Exception) {
                    toast("Rename failed")
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun deleteVideo(v: Video) {
        AlertDialog.Builder(this)
            .setTitle("🗑 Delete video?")
            .setMessage("\"${v.title}\" will be deleted from your device. This cannot be undone.")
            .setPositiveButton("Delete") { _, _ ->
                try {
                    if (Build.VERSION.SDK_INT >= 30) {
                        val req = MediaStore.createDeleteRequest(contentResolver, listOf(v.uri))
                        startIntentSenderForResult(req.intentSender, REQ_DELETE, null, 0, 0, 0)
                    } else {
                        val n = contentResolver.delete(v.uri, null, null)
                        if (n > 0) { toast("Video deleted"); loadLibrary() } else toast("Delete not allowed")
                    }
                } catch (e: Exception) {
                    toast("Delete failed")
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---------------- adapters ----------------
    inner class FolderAdapter(private val folders: List<Pair<String, List<Video>>>) : BaseAdapter() {
        override fun getCount() = folders.size
        override fun getItem(pos: Int) = folders[pos]
        override fun getItemId(pos: Int) = pos.toLong()
        override fun getView(pos: Int, convertView: View?, parent: ViewGroup?): View {
            val ctx = this@MainActivity
            val (name, vids) = folders[pos]
            val totalDur = vids.sumOf { it.duration }
            val row = LinearLayout(ctx)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(Ui.dp(ctx, 16), Ui.dp(ctx, 12), Ui.dp(ctx, 16), Ui.dp(ctx, 12))
            row.background = Ui.cardBg(18, Ui.SURFACE)
            row.elevation = Ui.dp(ctx, 4).toFloat()
            val icon = Ui.text(ctx, "📁", 26f, Ui.TEXT)
            icon.setPadding(0, 0, Ui.dp(ctx, 12), 0)
            row.addView(icon)
            val col = LinearLayout(ctx)
            col.orientation = LinearLayout.VERTICAL
            col.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            col.addView(Ui.text(ctx, name, 15f, Ui.TEXT, true))
            col.addView(Ui.text(ctx, "${vids.size} videos • ${Library.fmtTime(totalDur)} total", 12f, Ui.MUTED))
            row.addView(col)
            row.addView(Ui.text(ctx, "›", 22f, Ui.MUTED))
            val outer = LinearLayout(ctx)
            outer.orientation = LinearLayout.VERTICAL
            outer.setPadding(Ui.dp(ctx, 14), Ui.dp(ctx, 5), Ui.dp(ctx, 14), Ui.dp(ctx, 5))
            outer.addView(row)
            return outer
        }
    }

    inner class PlaylistAdapter(private val pls: List<Pair<String, List<Long>>>) : BaseAdapter() {
        override fun getCount() = pls.size
        override fun getItem(pos: Int) = pls[pos]
        override fun getItemId(pos: Int) = pos.toLong()
        override fun getView(pos: Int, convertView: View?, parent: ViewGroup?): View {
            val ctx = this@MainActivity
            val (name, ids) = pls[pos]
            val row = LinearLayout(ctx)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(Ui.dp(ctx, 16), Ui.dp(ctx, 12), Ui.dp(ctx, 16), Ui.dp(ctx, 12))
            row.background = Ui.cardBg(18, Ui.SURFACE)
            row.elevation = Ui.dp(ctx, 4).toFloat()
            val icon = Ui.text(ctx, "🎵", 24f, Ui.TEXT)
            icon.setPadding(0, 0, Ui.dp(ctx, 12), 0)
            row.addView(icon)
            val col = LinearLayout(ctx)
            col.orientation = LinearLayout.VERTICAL
            col.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            col.addView(Ui.text(ctx, name, 15f, Ui.TEXT, true))
            col.addView(Ui.text(ctx, "${ids.size} videos  (long-press: rename / delete)", 12f, Ui.MUTED))
            row.addView(col)
            row.addView(Ui.text(ctx, "›", 22f, Ui.MUTED))
            val outer = LinearLayout(ctx)
            outer.orientation = LinearLayout.VERTICAL
            outer.setPadding(Ui.dp(ctx, 14), Ui.dp(ctx, 5), Ui.dp(ctx, 14), Ui.dp(ctx, 5))
            outer.addView(row)
            return outer
        }
    }

    private fun bindThumb(thumb: ImageView, v: Video) {
        val cached = thumbCache[v.id]
        if (cached != null) {
            thumb.setImageBitmap(cached)
        } else {
            thumb.setImageBitmap(null)
            if (!thumbLoading.contains(v.id)) {
                thumbLoading.add(v.id)
                thread {
                    val bmp = Library.thumbnail(this@MainActivity, v)
                    thumbCache[v.id] = bmp
                    thumbLoading.remove(v.id)
                    runOnUiThread {
                        if (::listView.isInitialized) (listView.adapter as? BaseAdapter)?.notifyDataSetChanged()
                        if (::gridView.isInitialized) (gridView.adapter as? BaseAdapter)?.notifyDataSetChanged()
                    }
                }
            }
        }
    }

    inner class VideoAdapter(private val videos: List<Video>) : BaseAdapter() {
        override fun getCount() = videos.size
        override fun getItem(pos: Int) = videos[pos]
        override fun getItemId(pos: Int) = videos[pos].id
        override fun getView(pos: Int, convertView: View?, parent: ViewGroup?): View {
            val ctx = this@MainActivity
            val v = videos[pos]
            // Card with breathing room around it (signature design)
            val outer = LinearLayout(ctx)
            outer.orientation = LinearLayout.VERTICAL
            outer.setPadding(Ui.dp(ctx, 14), Ui.dp(ctx, 5), Ui.dp(ctx, 14), Ui.dp(ctx, 5))
            val row = LinearLayout(ctx)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(Ui.dp(ctx, 10), Ui.dp(ctx, 10), Ui.dp(ctx, 6), Ui.dp(ctx, 10))
            row.background = Ui.cardBg(18, Ui.SURFACE)
            row.elevation = Ui.dp(ctx, 4).toFloat()
            outer.addView(row)

            // Thumbnail with a duration badge in its corner
            val thumbFrame = android.widget.FrameLayout(ctx)
            thumbFrame.layoutParams = LinearLayout.LayoutParams(Ui.dp(ctx, 118), Ui.dp(ctx, 70))
            val thumb = ImageView(ctx)
            thumb.layoutParams = android.widget.FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            thumb.scaleType = ImageView.ScaleType.CENTER_CROP
            thumb.background = Ui.cardBg(10, Ui.ELEVATED)
            bindThumb(thumb, v)
            thumbFrame.addView(thumb)
            val badge = Ui.text(ctx, Library.fmtTime(v.duration), 10f, android.graphics.Color.WHITE, true)
            badge.setBackgroundColor(0xB3000000.toInt())
            badge.setPadding(Ui.dp(ctx, 5), Ui.dp(ctx, 1), Ui.dp(ctx, 5), Ui.dp(ctx, 1))
            val blp = android.widget.FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            blp.gravity = Gravity.BOTTOM or Gravity.RIGHT
            blp.setMargins(0, 0, Ui.dp(ctx, 4), Ui.dp(ctx, 4))
            thumbFrame.addView(badge, blp)
            row.addView(thumbFrame)

            val col = LinearLayout(ctx)
            col.orientation = LinearLayout.VERTICAL
            col.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            col.setPadding(Ui.dp(ctx, 10), 0, Ui.dp(ctx, 4), 0)
            val titleT = Ui.text(ctx, v.title, 14.5f, Ui.TEXT, true)
            titleT.maxLines = 2
            col.addView(titleT)
            val resume = Prefs.resumePos(v.id)
            val meta = "${Library.fmtTime(v.duration)} • ${v.resolution} • ${Library.fmtSize(v.sizeBytes)}" +
                (if (resume > 0) " • ▶ resume ${Library.fmtTime(resume)}" else "")
            col.addView(Ui.text(ctx, meta, 11.5f, Ui.MUTED))
            col.addView(Ui.text(ctx, "📁 ${v.folder}", 11.5f, Ui.MUTED))
            row.addView(col)

            val fav = TextView(ctx)
            fav.text = if (Prefs.isFavorite(v.id)) "★" else "☆"
            fav.setTextColor(if (Prefs.isFavorite(v.id)) Ui.GOLD else Ui.MUTED)
            fav.textSize = 22f
            fav.setPadding(Ui.dp(ctx, 6), Ui.dp(ctx, 8), Ui.dp(ctx, 2), Ui.dp(ctx, 8))
            fav.setOnClickListener {
                val now = Prefs.toggleFavorite(v.id)
                toast(if (now) "Added to favorites" else "Removed from favorites")
                refreshList()
            }
            row.addView(fav)
            val dots = TextView(ctx)
            dots.text = "⋮"
            dots.setTextColor(Ui.MUTED)
            dots.textSize = 20f
            dots.setPadding(Ui.dp(ctx, 2), Ui.dp(ctx, 8), Ui.dp(ctx, 6), Ui.dp(ctx, 8))
            dots.setOnClickListener { showVideoMenu(v) }
            row.addView(dots)
            return outer
        }
    }

    inner class VideoGridAdapter(private val videos: List<Video>) : BaseAdapter() {
        override fun getCount() = videos.size
        override fun getItem(pos: Int) = videos[pos]
        override fun getItemId(pos: Int) = videos[pos].id
        override fun getView(pos: Int, convertView: View?, parent: ViewGroup?): View {
            val ctx = this@MainActivity
            val v = videos[pos]
            val cell = LinearLayout(ctx)
            cell.orientation = LinearLayout.VERTICAL
            cell.setPadding(Ui.dp(ctx, 4), Ui.dp(ctx, 4), Ui.dp(ctx, 4), Ui.dp(ctx, 6))
            cell.background = Ui.cardBg(10, Ui.SURFACE)
            val thumb = ImageView(ctx)
            thumb.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(ctx, 84))
            thumb.scaleType = ImageView.ScaleType.CENTER_CROP
            thumb.background = Ui.cardBg(8, Ui.ELEVATED)
            bindThumb(thumb, v)
            cell.addView(thumb)
            val t = Ui.text(ctx, v.title, 11.5f, Ui.TEXT, true)
            t.maxLines = 2
            t.setPadding(0, Ui.dp(ctx, 4), 0, 0)
            cell.addView(t)
            cell.addView(Ui.text(ctx, Library.fmtTime(v.duration), 10.5f, Ui.MUTED))
            return cell
        }
    }
}
