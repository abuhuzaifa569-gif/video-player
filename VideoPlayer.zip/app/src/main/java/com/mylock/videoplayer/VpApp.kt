package com.mylock.videoplayer

import android.app.Application
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter

class VpApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        installCrashRecorder()
    }

    /**
     * If anything ever crashes, save the stack trace to last_crash.txt so the
     * library screen can show it (and the user can screenshot it for support).
     * The system crash flow continues unchanged afterwards.
     */
    private fun installCrashRecorder() {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            try {
                val sw = StringWriter()
                error.printStackTrace(PrintWriter(sw))
                val trace = "Video Player crash on ${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL} " +
                    "(Android ${android.os.Build.VERSION.RELEASE})\n" + sw.toString()
                File(filesDir, "last_crash.txt").writeText(trace.take(6000))
            } catch (e: Exception) { }
            previous?.uncaughtException(thread, error)
        }
    }
}
