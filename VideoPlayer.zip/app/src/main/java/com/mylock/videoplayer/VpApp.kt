package com.mylock.videoplayer

import android.app.Application

class VpApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
    }
}
