package com.mylock.videoplayer

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.view.View
import android.view.WindowInsets
import android.widget.TextView

/**
 * v2.0 "Crimson" theme — deliberately different from the Music Player's
 * Midnight-blue look. Dark (charcoal + crimson/orange) and Light variants;
 * colors are vars so applyTheme() can swap the whole palette at runtime.
 */
object Ui {
    var BG = Color.parseColor("#141114")
    var SURFACE = Color.parseColor("#1F1A1E")
    var ELEVATED = Color.parseColor("#2C242A")
    var PRIMARY = Color.parseColor("#E0243C")
    var PRIMARY2 = Color.parseColor("#FF7A18")
    var SECONDARY = Color.parseColor("#FF8A5C")
    var TEXT = Color.parseColor("#FFF5F2")
    var MUTED = Color.parseColor("#B8A6AD")
    var ERROR = Color.parseColor("#FF6B6B")
    var GOLD = Color.parseColor("#FFC857")

    /** Swap the whole palette. Call before buildUi() in every activity. */
    fun applyTheme(dark: Boolean) {
        if (dark) {
            BG = Color.parseColor("#141114")
            SURFACE = Color.parseColor("#1F1A1E")
            ELEVATED = Color.parseColor("#2C242A")
            TEXT = Color.parseColor("#FFF5F2")
            MUTED = Color.parseColor("#B8A6AD")
        } else {
            BG = Color.parseColor("#F7F3F4")
            SURFACE = Color.parseColor("#FFFFFF")
            ELEVATED = Color.parseColor("#EFE7EA")
            TEXT = Color.parseColor("#231A1E")
            MUTED = Color.parseColor("#7A6A70")
        }
        PRIMARY = Color.parseColor("#E0243C")
        PRIMARY2 = Color.parseColor("#FF7A18")
        SECONDARY = Color.parseColor("#FF8A5C")
    }

    fun dp(ctx: Context, v: Int): Int = (v * ctx.resources.displayMetrics.density).toInt()

    fun text(ctx: Context, s: String, sp: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(ctx)
        t.text = s
        t.textSize = sp
        t.setTextColor(color)
        if (bold) t.typeface = Typeface.DEFAULT_BOLD
        return t
    }

    fun cardBg(radiusDp: Int, color: Int): GradientDrawable {
        val g = GradientDrawable()
        g.shape = GradientDrawable.RECTANGLE
        g.cornerRadius = radiusDp * 8f
        g.setColor(color)
        return g
    }

    fun gradientBtn(radiusDp: Int): GradientDrawable {
        val g = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(PRIMARY, PRIMARY2))
        g.shape = GradientDrawable.RECTANGLE
        g.cornerRadius = radiusDp * 8f
        return g
    }

    /** Android 15 enforces edge-to-edge: pad the root for the system bars. */
    fun edgeToEdge(activity: Activity, root: View) {
        try {
            if (Build.VERSION.SDK_INT >= 35) {
                activity.window.setDecorFitsSystemWindows(false)
                activity.window.statusBarColor = Color.TRANSPARENT
                activity.window.navigationBarColor = Color.TRANSPARENT
            } else {
                activity.window.statusBarColor = BG
                activity.window.navigationBarColor = BG
            }
            if (Build.VERSION.SDK_INT >= 30) {
                root.setOnApplyWindowInsetsListener { v, insets ->
                    val bars = insets.getInsets(WindowInsets.Type.systemBars())
                    v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
                    insets
                }
            } else {
                @Suppress("DEPRECATION")
                root.setOnApplyWindowInsetsListener { v, insets ->
                    v.setPadding(
                        insets.systemWindowInsetLeft, insets.systemWindowInsetTop,
                        insets.systemWindowInsetRight, insets.systemWindowInsetBottom
                    )
                    insets
                }
            }
            root.requestApplyInsets()
        } catch (e: Exception) { /* older devices just use the default layout */ }
    }
}
