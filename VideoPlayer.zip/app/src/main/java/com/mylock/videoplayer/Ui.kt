package com.mylock.videoplayer

import android.app.Activity
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.view.View
import android.view.WindowInsets
import android.widget.TextView

/**
 * v2.0 "Crimson" theme — deliberately different from the Music Player's
 * Midnight-blue look. Dark (charcoal + crimson/orange) and Light variants;
 * colors are vars so applyTheme() can swap the whole palette at runtime.
 */
object Ui {
    var BG = Color.parseColor("#141114")
    var SURFACE = Color.parseColor("#1F1A1E")
    var ELEVATED = Color.parseColor("#2C242A")
    var PRIMARY = Color.parseColor("#E0243C")
    var PRIMARY2 = Color.parseColor("#FF7A18")
    var SECONDARY = Color.parseColor("#FF8A5C")
    var TEXT = Color.parseColor("#FFF5F2")
    var MUTED = Color.parseColor("#B8A6AD")
    var ERROR = Color.parseColor("#FF6B6B")
    var GOLD = Color.parseColor("#FFC857")

    /** Swap the whole palette. Call before buildUi() in every activity. */
    fun applyTheme(dark: Boolean) {
        if (dark) {
            // Signature dark: deep charcoal cards on near-black (Moiz's design)
            BG = Color.parseColor("#101013")
            SURFACE = Color.parseColor("#1E1E24")
            ELEVATED = Color.parseColor("#2B2B33")
            TEXT = Color.parseColor("#FFFFFF")
            MUTED = Color.parseColor("#A7A7AE")
        } else {
            // Signature light: warm cream with white cards (Moiz's design)
            BG = Color.parseColor("#FFF6EC")
            SURFACE = Color.parseColor("#FFFFFF")
            ELEVATED = Color.parseColor("#FDEBD7")
            TEXT = Color.parseColor("#2B1A12")
            MUTED = Color.parseColor("#9A7B68")
        }
        PRIMARY = Color.parseColor("#E0243C")
        PRIMARY2 = Color.parseColor("#FF7A18")
        SECONDARY = Color.parseColor("#FF8A5C")
    }

    fun dp(ctx: Context, v: Int): Int = (v * ctx.resources.displayMetrics.density).toInt()

    fun text(ctx: Context, s: String, sp: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(ctx)
        t.text = s
        t.textSize = sp
        t.setTextColor(color)
        if (bold) t.typeface = Typeface.DEFAULT_BOLD
        return t
    }

    fun cardBg(radiusDp: Int, color: Int): GradientDrawable {
        val g = GradientDrawable()
        g.shape = GradientDrawable.RECTANGLE
        g.cornerRadius = radiusDp * 8f
        g.setColor(color)
        return g
    }

    fun gradientBtn(radiusDp: Int): GradientDrawable {
        val g = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(PRIMARY, PRIMARY2))
        g.shape = GradientDrawable.RECTANGLE
        g.cornerRadius = radiusDp * 8f
        return g
    }

    /** Round (circular) button background, like the signature design's header buttons. */
    fun circleBg(color: Int): GradientDrawable {
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(color)
        return g
    }

    /** Thin crimson→orange gradient strip (signature top/bottom accent). */
    fun gradientStrip(): GradientDrawable {
        val g = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(PRIMARY, PRIMARY2))
        g.shape = GradientDrawable.RECTANGLE
        return g
    }

    /**
     * The signature design's flowing wave across the top of the screen,
     * drawn once into a bitmap (light: bright crimson→orange sweep;
     * dark: subtle deep-maroon glow, like the mockups).
     */
    fun waveBitmap(w: Int, h: Int, dark: Boolean): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        // Back layer (lighter, offset sweep)
        val back = Path()
        back.moveTo(0f, 0f)
        back.lineTo(w.toFloat(), 0f)
        back.lineTo(w.toFloat(), h * 0.30f)
        back.cubicTo(w * 0.70f, h * 0.75f, w * 0.38f, h * 0.30f, 0f, h * 0.95f)
        back.close()
        val backPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        backPaint.color = if (dark) Color.parseColor("#57101C") else Color.parseColor("#FFB98A")
        backPaint.alpha = if (dark) 110 else 130
        c.drawPath(back, backPaint)
        // Front layer (main sweep from the top-right)
        val front = Path()
        front.moveTo(0f, 0f)
        front.lineTo(w.toFloat(), 0f)
        front.lineTo(w.toFloat(), h * 0.52f)
        front.cubicTo(w * 0.78f, h * 0.52f, w * 0.55f, h * 1.0f, w * 0.18f, h * 0.62f)
        front.cubicTo(w * 0.05f, h * 0.50f, 0f, h * 0.55f, 0f, h * 0.40f)
        front.close()
        val frontPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        frontPaint.shader = LinearGradient(
            0f, 0f, w.toFloat(), h.toFloat(),
            if (dark) Color.parseColor("#5E0F1A") else PRIMARY,
            if (dark) Color.parseColor("#2A060B") else PRIMARY2,
            Shader.TileMode.CLAMP
        )
        frontPaint.alpha = if (dark) 165 else 255
        c.drawPath(front, frontPaint)
        return bmp
    }

    /** Android 15 enforces edge-to-edge: pad the root for the system bars. */
    fun edgeToEdge(activity: Activity, root: View) {
        try {
            if (Build.VERSION.SDK_INT >= 35) {
                activity.window.setDecorFitsSystemWindows(false)
                activity.window.statusBarColor = Color.TRANSPARENT
                activity.window.navigationBarColor = Color.TRANSPARENT
            } else {
                activity.window.statusBarColor = BG
                activity.window.navigationBarColor = BG
            }
            if (Build.VERSION.SDK_INT >= 30) {
                root.setOnApplyWindowInsetsListener { v, insets ->
                    val bars = insets.getInsets(WindowInsets.Type.systemBars())
                    v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
                    insets
                }
            } else {
                @Suppress("DEPRECATION")
                root.setOnApplyWindowInsetsListener { v, insets ->
                    v.setPadding(
                        insets.systemWindowInsetLeft, insets.systemWindowInsetTop,
                        insets.systemWindowInsetRight, insets.systemWindowInsetBottom
                    )
                    insets
                }
            }
            root.requestApplyInsets()
        } catch (e: Exception) { /* older devices just use the default layout */ }
    }
}
