package com.mylock.videoplayer

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.view.View
import android.view.WindowInsets
import android.widget.TextView

/** Midnight dark theme — consistent with Moiz's other standalone apps. */
object Ui {
    var BG = Color.parseColor("#0B1220")
    var SURFACE = Color.parseColor("#16213A")
    var ELEVATED = Color.parseColor("#1E2C4E")
    var PRIMARY = Color.parseColor("#4D7CFE")
    var PRIMARY2 = Color.parseColor("#7C4DFF")
    var SECONDARY = Color.parseColor("#00D4B8")
    var TEXT = Color.parseColor("#EAF0FF")
    var MUTED = Color.parseColor("#93A4C4")
    var ERROR = Color.parseColor("#FF6B6B")
    var GOLD = Color.parseColor("#FFC857")

    fun dp(ctx: Context, v: Int): Int = (v * ctx.resources.displayMetrics.density).toInt()

    fun text(ctx: Context, s: String, sp: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(ctx)
        t.text = s
        t.textSize = sp
        t.setTextColor(color)
        if (bold) t.typeface = Typeface.DEFAULT_BOLD
        return t
    }

    fun cardBg(radiusDp: Int, color: Int): GradientDrawable {
        val g = GradientDrawable()
        g.shape = GradientDrawable.RECTANGLE
        g.cornerRadius = radiusDp * 8f
        g.setColor(color)
        return g
    }

    fun gradientBtn(radiusDp: Int): GradientDrawable {
        val g = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(PRIMARY, PRIMARY2))
        g.shape = GradientDrawable.RECTANGLE
        g.cornerRadius = radiusDp * 8f
        return g
    }

    /** Android 15 enforces edge-to-edge: pad the root for the system bars. */
    fun edgeToEdge(activity: Activity, root: View) {
        try {
            if (Build.VERSION.SDK_INT >= 35) {
                activity.window.setDecorFitsSystemWindows(false)
                activity.window.statusBarColor = Color.TRANSPARENT
                activity.window.navigationBarColor = Color.TRANSPARENT
            } else {
                activity.window.statusBarColor = BG
                activity.window.navigationBarColor = BG
            }
            if (Build.VERSION.SDK_INT >= 30) {
                root.setOnApplyWindowInsetsListener { v, insets ->
                    val bars = insets.getInsets(WindowInsets.Type.systemBars())
                    v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
                    insets
                }
            } else {
                @Suppress("DEPRECATION")
                root.setOnApplyWindowInsetsListener { v, insets ->
                    v.setPadding(
                        insets.systemWindowInsetLeft, insets.systemWindowInsetTop,
                        insets.systemWindowInsetRight, insets.systemWindowInsetBottom
                    )
                    insets
                }
            }
            root.requestApplyInsets()
        } catch (e: Exception) { /* older devices just use the default layout */ }
    }
}
